/*
Rebecca Flake
4-9-2018 Through 4-30-2018 
Java
Version 8
Includes: 
   Java-
	File, FileWriter, and IOException classes
	Scanner class
	LinkedList class
   JavaFx-
	Platform classe
	ActionEvent and EventHandler classes
	HPos, Insets, Orientation, and Pos classes
	Scene, Node classes, 
	Stage class
	Button,ContentDisplay, Label, and TextField classes
	Drop shadow class
	ImageView class
	BorderPane, GridPane, HBox, StackPane, and VBox classes
	Media and MediaPlayer classes
	Color class
	Rectangle class
	Font, TextAlignment, and Text classes
   Images-
    cardBack.jpg
   Files
   	gameData.txt
   	highScore.txt
COP2552.001
Final Project
This program allows the user to play a game of Blackjack with a graphical user interface.  The user can also view instructions on how to play, View the top ten scores 
of all time, and view the game data from the 10 most recently played games.
 */
package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;


/** BlackJackGUI class. Handlers the tasks related to the user experience. Accesses the BlackJackGame class to run the game itself*/
class BlackJackGUI {
	//Create the static file reference variables
	static File bHighScoreFile;
	static File bGameDataFile;		
	static Scanner bHighScoreFileIn;
	static Scanner bGameDataFileIn;
	static FileWriter bHighScoreFileOut;
	static FileWriter bGameDataFileOut;

	//Create empty array lists for the card images
	static LinkedList<ImageView> pCardImgs = new LinkedList<ImageView>();
	static LinkedList<ImageView> dCardImgs = new LinkedList<ImageView>();
	
	//string variable for the player's username
	static String name = " ";
	
	//Game data object for the games
	static GameData games;

	/** Method that starts the blackjack game gui*/
	static void startBlackjack(Stage primaryStage, String n)	{
		//set the passed string to the name
		name = n;
		//create the file objects
		bHighScoreFile = new File("bHighScore.txt");	
		bGameDataFile = new File("bGameData.txt");		
				
		try {	
			//create new files if none exist
			if (!bHighScoreFile.exists()){
				 bHighScoreFileOut = new FileWriter(bHighScoreFile);
			}
			if (!bGameDataFile.exists()){
				 bGameDataFileOut = new FileWriter(bGameDataFile);
			}		
			//create the game data object
			games = new GameData(bGameDataFile);	
			games.readData(bGameDataFile);
			
			//Set the title of the primary stage
			primaryStage.setTitle("BlackJack");
			//set the starting sizes for the stage
			primaryStage.setWidth(1200);
			primaryStage.setHeight(700);
			//set the minimum sizes for the stage
			primaryStage.setMinWidth(1200);
			primaryStage.setMinHeight(700);
			//Get the menu, which is the first scene
			getMenu(primaryStage);
		} 
		//catch any exceptions
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	/* ******************************************************************************************************************************************************** 
	 * Methods that create the 'top level' scenes for the game. These include the menu * 
	 * scene method and the methods that will be called from the menu directly.		  *
	 * **************************************************************************************************************************************************** */
	
	/** Method that will create the main menu for the game*/
	static void getMenu(Stage primaryStage){
		//create the UI elements
		Button newGameBt = setButton("New Game");			//Button object that will allow the user to start a new game of blackjack
			newGameBt.setMinWidth(200);
		Button howToPlayBt = setButton("How to Play");			//Button object that will allow the user to view game instructions
			howToPlayBt.setMinWidth(200);
		Button highScoresBt = setButton("High Scores");			//Button object that will allow the user to see the top ten scores
			highScoresBt.setMinWidth(200);
		Button gameHistoryBt = setButton("Game History");		//Button object that will allow the user to see game history
			gameHistoryBt.setMinWidth(200);
		Button returnBt = setButton("Return to Game"+ "\nSelection Menu");		//Button object that will allow the user to return to the game selection menu						
			returnBt.setMinWidth(200);
			returnBt.setPrefWidth(200);
		Button exitBt = setButton("Exit");						//Button object that will allow the user to close the program
			exitBt.setMinWidth(200);		
			
		//Text
		Text gameNameTxt = new Text("1 v 1 Blackjack");		//Text object for the scene title
			gameNameTxt.setStyle("-fx-font-size: 2em;");
			gameNameTxt.setFont(Font.font("Abyssinica SIL", 24));
			gameNameTxt.setFill(Color.color(.21, .09, .23));
			
		//Create the VBox and add its nodes
		VBox menuColumn = new VBox(35);
			menuColumn.getChildren().add(gameNameTxt);
			menuColumn.getChildren().add(newGameBt);
			menuColumn.getChildren().add(howToPlayBt);
			menuColumn.getChildren().add(highScoresBt);
			menuColumn.getChildren().add(gameHistoryBt);
			menuColumn.getChildren().add(returnBt);
			menuColumn.getChildren().add(exitBt);
			menuColumn.setAlignment(Pos.CENTER);
			
		//Create a border pane
		BorderPane menuPane = new BorderPane();
			menuPane.setCenter(menuColumn);		
			menuPane.setStyle("-fx-background-color: #BFA6A3;");
		/*Create a scene and place the pane into it, set it as the primary stage's scene
		the height and width are set to what ever the current size of the primary stage is - this seems to then apply to all scenes until it is overridden*/
		Scene menuScene = new Scene(menuPane, primaryStage.getWidth(), primaryStage.getHeight());
		primaryStage.setScene(menuScene);
			
		//Display the Stage
		primaryStage.show();

		//Listeners for the stage size so that the scene can be resized
		primaryStage.widthProperty().addListener(ov -> {menuPane.setPrefWidth(primaryStage.getWidth());});
		primaryStage.heightProperty().addListener(ov-> {menuPane.setPrefHeight(primaryStage.getHeight());});
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(newGameBt);
		fireOnEnter(howToPlayBt);	
		fireOnEnter(highScoresBt);	
		fireOnEnter(gameHistoryBt);	
		fireOnEnter(returnBt);	
		fireOnEnter(exitBt);	
		//Event handlers for the buttons
			//Start a new game
		newGameBt.setOnAction(e -> newGame(primaryStage));
			//Get instructions
		howToPlayBt.setOnAction(e -> howToPlayDisplay(primaryStage));
			//Display the high scores
		highScoresBt.setOnAction(e -> highScoreDisplay(primaryStage));
			//Display the 10 most recently played games
		gameHistoryBt.setOnAction(e -> gameHistoryDisplay(primaryStage));
			//return the main menu
		returnBt.setOnAction(e-> Main.mainMenu());
			//exit the program
		exitBt.setOnAction(e -> exit());
			//handler for the window's exit button
		primaryStage.setOnCloseRequest(windowEvent -> {
			//consume the event
			windowEvent.consume();
			//then call exit to close the program gracefully if the user is sure
			exit();
		});
	}
	

	/** Method that starts a new game*/
	static void newGame(Stage primaryStage){
	//create the UI elements
		//Text
		Text titleTxt = new Text("Let's play Blackjack!");											 	//text object to hold the scene's title	
			titleTxt.setFont(Font.font("Abyssinica SIL", 28));
			titleTxt.setFill(Color.color(.21, .09, .23));
		//create the UI elements
		Text txt = new Text("How many decks\ndo you want\nto play with");								//text object to hold the question
			txt.setTextAlignment(TextAlignment.CENTER);
			txt.setFont(Font.font("Abyssinica SIL", 20));
			txt.setFill(Color.color(.21, .09, .23));
		//button
		Button sixBt = setButton("Six (6)");																//button that will allow the user to play with 6 decks
		Button oneBt = setButton("One (1)");																//button that will allow the user to player with one deck
		Button backBt = setButton("Back to Menu");														//button that will allow the user to return to the menu

		//hbox for the buttons
		HBox hBox= new HBox(20);
			hBox.setAlignment(Pos.CENTER);	
			hBox.getChildren().add(sixBt);
			hBox.getChildren().add(oneBt);
		//vbox for the text and the buttons
		VBox vBox= new VBox(35);
			vBox.setAlignment(Pos.CENTER);		
			vBox.getChildren().add(titleTxt);
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);
			vBox.getChildren().add(backBt);

		//Create a border pane
		BorderPane startGamePane = new BorderPane();
			startGamePane.setCenter(vBox);
			startGamePane.setStyle("-fx-background-color: #BFA6A3;");
		//Set the scene and the stage, display it
		primaryStage.setScene(new Scene(startGamePane, 1200, 700));
		primaryStage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(sixBt);
		fireOnEnter(oneBt);	
		fireOnEnter(backBt);	
		
	//Event handlers for the buttons
		//Event handlers
		sixBt.setOnAction(e -> {
			startGame(primaryStage, name, 6);
		});
		//if the answer is no, close the new stage
		oneBt.setOnAction(e -> {
			startGame(primaryStage, name, 1);
		});
		//event handler for the back button
		backBt.setOnAction(e -> {
			getMenu(primaryStage);
		});
	}

	/** Method that creates a scene that gives the user instructions on how to play the game*/
	static void howToPlayDisplay(Stage primaryStage){
	//Create the UI Elements
		//A text object with the scene's title
		Text txt = new Text("Game Instructions");																				
			//Set the style for the text
			txt.setStyle("-fx-text-align: center;-fx-padding-top: 1.5em;");
			txt.setFont(Font.font("Abyssinica SIL", 24));
			txt.setFill(Color.color(.21, .09, .23));
		//A text object to hold the instructions for the game
		Text instructions = new Text("Blackjack, also known as 21, is a card game where the object is to get as close to a score of 21 as possible\nwithout going over. "
				+ "\n\nEach non-face card is worth the number on the card. Face cards are worth ten points and aces are worth 1 or 11\npoints, depending on which"
				+ " is better for the player. \n\nAt the beginning of each hand the player will make a bet. Once the bet has been made the player\n and the dealer "
				+ "will each be dealt 2 cards. The player will be able to see both of their own cards,\nbut they will only be able to see 1 of the dealer’s cards. "
				+ "\n\nBets must be between 1 and 100. Once you make your bet and begin the game it cannot be changed. \nIf a player gets 21 on their first set "
				+ "of cards, a natural, they will get 1.5x their bet. If a player wins by any other\nmeans they get the value of their initial bet. If the dealer wins "
				+ "the player loses their bet.\n\nYou can choose to shuffle the cards after each hand. Once 25% of the cards in the deck remain it will\nautomatically"
				+ " be shuffled.  \n\nOn your turn you can choose to hit or to stand. If you hit you will draw another card, if you\ngo over 21 you will lose. If you "
				+ "stand you will draw no more cards, the dealer will then draw cards until\nthey go over 17, regardless of if they wil go over 21. Once you stand the "
				+ "hand is over. \n\nIf you quit the game before the end of a hand you will not have the opportunity to be\nadded to the top 10.");	
			instructions.setStyle("-fx-line-height: 4em;");
			instructions.setFont(Font.font("Abyssinica SIL", 18));
			instructions.setFill(Color.color(.21, .09, .23));
		//create a scroll pane to hold the history container
		ScrollPane scroll = new ScrollPane(instructions);
			scroll.setMaxWidth(1000);
			scroll.setMaxHeight(430);
			scroll.setPadding(new Insets(5,5,5,5));
			scroll.setStyle("-fx-background: #BFA6A3; -fx-background-color: #BFA6A3;");

		//A button object that will allow the user to go back to the menu	
		Button backBt = setButton("Back to Menu");

		//A vertical box pane to hold the UL elements
		VBox vBox= new VBox();
			vBox.setAlignment(Pos.CENTER);
			vBox.setSpacing(15);
			vBox.setPadding(new Insets(5,5,5,5));
			vBox.getChildren().add(txt);
			vBox.getChildren().add(scroll);
			vBox.getChildren().add(backBt);

		//Create a border pane
		BorderPane howToPane = new BorderPane();
			howToPane.setCenter(vBox);
			howToPane.setStyle("-fx-background-color: #BFA6A3;");
		//Set the scene and the stage, display it
		primaryStage.setScene(new Scene(howToPane, 700, 500));
		primaryStage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(backBt);	
		//event handler for the button
		backBt.setOnAction(e -> getMenu(primaryStage));
	}

	/** Method that shows the high scores*/
	static void highScoreDisplay(Stage primaryStage){
		final int MAXSCORE = 10;														//Constant variable for the number of scores		
		//create the file scanner
		bHighScoreFileIn	= GameData.createFileScanner(bHighScoreFile, bHighScoreFileIn);
		//create the line counter
		int lineCount = 0;
		//string array for the scores
		String[] scores= new String[MAXSCORE];

		//get input from the file as long as the scanner isn't at the end of the file and the line count does't exceed the max number of scores
			while(bHighScoreFileIn.hasNext() && lineCount < MAXSCORE){
 				scores[lineCount] = "$" + bHighScoreFileIn.nextLine();
 				lineCount++;
 				}
			//close the input scanner
			bHighScoreFileIn.close();
			
	//Set up the UI elements
		//Text
		Text highScoreTitleTxt = new Text("High Scores");									//Text object for the title
			highScoreTitleTxt.setStyle("-fx-padding-top: 1.5em;");
			highScoreTitleTxt.setTextAlignment(TextAlignment.CENTER);
			highScoreTitleTxt.setFont(Font.font("Abyssinica SIL", 24));
			highScoreTitleTxt.setFill(Color.color(.21, .09, .23));
		//TextFields for the scores
		TextField score1Field = setTextField(scores[MAXSCORE - 10], false, 25);
			score1Field.setFocusTraversable(false);
		TextField score2Field = setTextField(scores[MAXSCORE - 9], false, 25);
			score2Field.setFocusTraversable(false);
		TextField score3Field = setTextField(scores[MAXSCORE - 8], false, 25);
			score3Field.setFocusTraversable(false);
		TextField score4Field = setTextField(scores[MAXSCORE - 7], false, 25);
			score4Field.setFocusTraversable(false);
		TextField score5Field = setTextField(scores[MAXSCORE - 6], false, 25);
			score5Field.setFocusTraversable(false);
		TextField score6Field = setTextField(scores[MAXSCORE - 5], false, 25);
			score6Field.setFocusTraversable(false);
		TextField score7Field = setTextField(scores[MAXSCORE - 4], false, 25);
			score7Field.setFocusTraversable(false);
		TextField score8Field = setTextField(scores[MAXSCORE - 3], false, 25);
			score8Field.setFocusTraversable(false);
		TextField score9Field = setTextField(scores[MAXSCORE - 2], false, 25);
			score9Field.setFocusTraversable(false);
		TextField score10Field = setTextField(scores[MAXSCORE-1], false, 25);
			score10Field.setFocusTraversable(false);
		
		//Labels
		Label score1Lbl = setLabel("1: ", score1Field);
			score1Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score2Lbl = setLabel("2: ", score2Field);
			score2Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score3Lbl = setLabel("3: ", score3Field);
			score3Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score4Lbl = setLabel("4: ", score4Field);
			score4Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score5Lbl = setLabel("5: ", score5Field);
			score5Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score6Lbl = setLabel("6: ", score6Field);
			score6Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score7Lbl = setLabel("7: ", score7Field);
			score7Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score8Lbl = setLabel("8: ", score8Field);
			score8Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score9Lbl = setLabel("9: ", score9Field);
			score9Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score10Lbl = setLabel("10: ", score10Field);
			score10Lbl.setContentDisplay(ContentDisplay.RIGHT);
			
		//button
		Button backBt = setButton("Back to Menu");

		//create a vbox
		VBox highScoreVbox = new VBox();
			highScoreVbox.setStyle("-fx-background-color: #BFA6A3;");
			highScoreVbox.setAlignment(Pos.CENTER);
			highScoreVbox.setSpacing(15);
			highScoreVbox.setAlignment(Pos.CENTER);
			highScoreVbox.setPadding(new Insets(10,10,10,10) );
			//add the nodes
			highScoreVbox.getChildren().add(highScoreTitleTxt);
			highScoreVbox.getChildren().add(score1Lbl);
			highScoreVbox.getChildren().add(score2Lbl);
			highScoreVbox.getChildren().add(score3Lbl);
			highScoreVbox.getChildren().add(score4Lbl);
			highScoreVbox.getChildren().add(score5Lbl);
			highScoreVbox.getChildren().add(score6Lbl);
			highScoreVbox.getChildren().add(score7Lbl);
			highScoreVbox.getChildren().add(score8Lbl);
			highScoreVbox.getChildren().add(score9Lbl);
			highScoreVbox.getChildren().add(score10Lbl);
			highScoreVbox.getChildren().add(backBt);

		//place the vBox in the scene
		Scene scene = new Scene(highScoreVbox, 700, 550);		
		primaryStage.setScene(scene);
		//Display the Stage
		primaryStage.show();
		
		//allow the user to fire the button when they press enter and the the button has the focus
		fireOnEnter(backBt);	
		//event handler for the button
		backBt.setOnAction(e -> getMenu(primaryStage));
		
	}
	
	/** Method that shows the game history*/
	static void gameHistoryDisplay(Stage primaryStage){
		//a string for the game data
		String gameData = "";
		//read in the file information
		//create the file scanner
		bGameDataFileIn	= GameData.createFileScanner(bGameDataFile, bGameDataFileIn);
		//if the file length is not zero and there are still lines to read
		if(!(bGameDataFile.length() == 0)){
			while(bGameDataFileIn.hasNext() ){
				//add the next line of data to the string
 				gameData += bGameDataFileIn.nextLine() + "\n";
 				}
		}
		else{
			gameData = "There is no game history to show.";
		}
		//close the input scanner
			bGameDataFileIn.close();
			
	//Create the UI Elements
		//Text
		Text gameHistoryTxt = new Text("Game History");							//A text object with the scene's title																			
			//Set the style for the text
			gameHistoryTxt.setStyle("-fx-padding-top: 1.5em;");
			gameHistoryTxt.setTextAlignment(TextAlignment.CENTER);
			gameHistoryTxt.setFont(Font.font("Abyssinica SIL", 24));
			gameHistoryTxt.setFill(Color.color(.21, .09, .23));
		Text gameDataTxt = new Text(gameData);									//A text area to hold the instructions for the game
			gameDataTxt.setStyle("-fx-line-height: 4em;");
			gameDataTxt.setFont(Font.font("Abyssinica SIL", 20));
			gameDataTxt.setTextAlignment(TextAlignment.CENTER);
			gameDataTxt.setFill(Color.color(.21, .09, .23));
		//create a scroll pane to hold the history container
		ScrollPane scroll = new ScrollPane(gameDataTxt);
			scroll.setMaxWidth(500);
			scroll.setMaxHeight(400);	
			scroll.setStyle("-fx-background: #BFA6A3; -fx-background-color: #BFA6A3;");
			scroll.setPadding(new Insets(0,0,0, 178));
			if(gameData == "There is no game history to show."){scroll.setPadding(new Insets(0,0,0, 100));}
		//Button
		Button backBt = setButton("Back to Menu");
		
		//A vertical box pane to hold the UI elements
		VBox vBox= new VBox();
			vBox.setAlignment(Pos.CENTER);
			vBox.setSpacing(15);
			vBox.setPadding(new Insets(5,5,5,5));		
			vBox.getChildren().add(gameHistoryTxt);
			vBox.getChildren().add(scroll);
			vBox.getChildren().add(backBt);

		//Create a border pane
		BorderPane gameDataPane = new BorderPane();
			gameDataPane.setStyle("-fx-background-color: #BFA6A3;");
			gameDataPane.setCenter(vBox);
		//Set the scene and the stage, display it
		primaryStage.setScene(new Scene(gameDataPane, 700, 500));
		primaryStage.show();
		
		//allow the user to fire the button when they press enter and the the button has the focus
		fireOnEnter(backBt);	
		//event handler for the button
		backBt.setOnAction(e -> getMenu(primaryStage));
	}
	
	/* *************************************************************************************************************************************************** * 
	 * Methods that create the scenes for the game itself, as well as setting up the   *  
	 * game instance itself. They all are called only if a new game is created.       *
	 * ************************************************************************************************************************************************** */

	/**method that starts the game*/
	static void startGame(Stage primaryStage, String name, int decks){
		//Create the instance of the game
		BlackJackGame game = new BlackJackGame(name, decks);
		//create the deck
		game.createDeck();
		//create the bet scene
		betScene(primaryStage, game);
		
		//a handler for the window's exit button. We want to make sure the program closes gracefully
		primaryStage.setOnCloseRequest(windowEvent -> {
			//consume the event
			windowEvent.consume();
			//then call exit to make sure the program is closed gracefully if the user decides that is what they want
			hardQuit(primaryStage, game);
		});
	}
	
	/** method that creates a scene to get the betting */
	static void betScene(Stage primaryStage, BlackJackGame game){
		//Set up the UI elements
			//Text
			Text instructTitle = new Text("Make your bet!");															//text object for the title
				instructTitle.setTextAlignment(TextAlignment.CENTER);
				instructTitle.setFont(Font.font("Abyssinica SIL", 24));
				instructTitle.setFill(Color.color(.21, .09, .23));
			Text instructTxt = new Text("Once you make a bet and begin the hand, you cannot change it.\n\n"				//text object for the instructions
					+ "If a you get 21 on your first set of cards, a natural, you will "
					+ "get 1.5x your bet.\n\nIf a you win by any other means you get the "
					+ "value of your initial bet.\n\nIf the dealer wins you lose your bet."
					+ "\n\nPlease make a bet. It must be 1-100.");
				instructTxt.setTextAlignment(TextAlignment.CENTER);
				instructTxt.setFont(Font.font("Abyssinica SIL", 16));
				instructTxt.setFill(Color.color(.21, .09, .23));
			//TextField
			TextField betTF = new TextField();																			//textField for the bet input
				betTF.setPrefColumnCount(5);
			//Button																										
			Button betBt = setButton("Bet");
			Button startHandBt = setButton("Begin the hand");
				startHandBt.setOpacity(.5);

			//Hbox for the betting
			HBox betHbox = new HBox(20);	
				betHbox.setPadding(new Insets(40, 0, 0 ,40));
				betHbox.setAlignment(Pos.CENTER);
				betHbox.getChildren().add(betTF);
				betHbox.getChildren().add(betBt);		
			//Vbox for the scene contents	
			VBox betVbox = new VBox(25);
				betVbox.getChildren().add(instructTitle);
				betVbox.getChildren().add(instructTxt);
				betVbox.getChildren().add(betHbox);
				betVbox.getChildren().add(startHandBt);
				betVbox.setAlignment(Pos.CENTER);
				betVbox.setStyle("-fx-background-color: #D8CACB;");
				//create the scene
			Scene handScene = new Scene(betVbox, 700, 600);
				
			//place the scene into the stage
			primaryStage.setScene(handScene);
			primaryStage.show();
			
			//allow the user to fire the buttons when they press enter and the the button has the focus
			fireOnEnter(betBt);	

			//bet button
			betBt.setOnAction(e-> {
				getBet(betTF, game);
			//allow the user to proceed now that they have made a bet
				startHandBt.setOpacity(1);	
				fireOnEnter(startHandBt);
				startHandBt.setOnAction(ActionEvent -> 	beginRound(primaryStage, game));
				});
	}
	
	
	/** Method that creates the GUI for the rounds of the game*/
	static void beginRound(Stage primaryStage, BlackJackGame game){
		//get the first cards for the player and the dealer 
		pCardImgs.add(new ImageView(game.drawCard("player")));
		pCardImgs.add(new ImageView(game.drawCard("player")));
		
		dCardImgs.add(new ImageView(game.drawCard("dealer")));
		dCardImgs.add(new ImageView(game.drawCard("dealer")));
		
		//call the create the hand scene method
		createHandScene(primaryStage, game, false);
		
	}
	
	/** Method that creates the scene for playing the hand */
	static void createHandScene(Stage primaryStage, BlackJackGame game, Boolean revealDealer){	
		//if the player has 21
		if(game.getPScore() == 21){
			revealDealer = true;	
			//if the player had 21 from the first 2 cards
			if(pCardImgs.size() == 2){
				game.setBetPool((int) (game.getBetPool() * 1.5));
			}
		}	
		
	//Set up the static UI elements		
		//set image view sizes ImageViews
		for(ImageView element: pCardImgs){
			element.setFitHeight(130);
			element.setFitWidth(80);
		}
		for(ImageView element: dCardImgs){
			element.setFitHeight(130);
			element.setFitWidth(80);
		}
		
		//Image to hold the back of the card
		ImageView backImg = new ImageView("/cardBack.jpg");	
			backImg.setFitHeight(130);
			backImg.setFitWidth(80);
		
		//Text
		Text handTitle = new Text("Let's Play!");															//text object for the title
			handTitle.setFont(Font.font("Abyssinica SIL", 24));
			handTitle.setFill(Color.color(.21, .09, .23));
		Text handsPlayedTxt = new Text(Integer.toString(game.getRoundCounter()));							//text object to hold the number of hands played
			handsPlayedTxt.setFont(Font.font("Abyssinica SIL", 16));
			handsPlayedTxt.setFill(Color.color(.21, .09, .23));
		Text winningsTxt = new Text(Integer.toString(game.getWinnings()));									//text object to hold the winnings
			winningsTxt.setFont(Font.font("Abyssinica SIL", 16));
			winningsTxt.setFill(Color.color(.21, .09, .23));
		Text pScoreTxt = new Text(Integer.toString(game.getPScore()));										//text object to hold the player score
			pScoreTxt.setFont(Font.font("Abyssinica SIL", 16));
			pScoreTxt.setFill(Color.color(.21, .09, .23));
			//if the player's score is over 21, increase the size of the text
			if(game.getPScore() > 21){pScoreTxt.setStyle("-fx-text-fill: #A3223B; -fx-font-size: 1.2em;");}
		Text dScoreTxt = new Text("???");																	//text object for the dealer's score
			dScoreTxt.setFont(Font.font("Abyssinica SIL", 16));
			dScoreTxt.setFill(Color.color(.21, .09, .23));
			//if the boolean parameter is true, reveal the dealer's score
			if(revealDealer){
				dScoreTxt.setText(Integer.toString(game.getDScore()));
			}
		Text poolTxt = new Text("$" + game.getBetPool());													//text object for the bet pool
			poolTxt.setFont(Font.font("Abyssinica SIL", 16));
			poolTxt.setFill(Color.color(.21, .09, .23));
				
		//Buttons
		Button hitBt = setButton("Hit");
		Button standBt = setButton("Stand");
		Button quitBt = setButton("Quit To Menu");

		//labels
		Label handsLbl = setLabel("Hands Played:", handsPlayedTxt);
			handsLbl.setContentDisplay(ContentDisplay.RIGHT);
			handsLbl.setPadding(new Insets(0, 0, 40 ,0));
		Label winningsLbl = setLabel("Total Winnings:", winningsTxt);
			winningsLbl.setContentDisplay(ContentDisplay.RIGHT);
			winningsLbl.setPadding(new Insets(0, 0, 40 ,0));
		Label pCardsLbl = setLabel("Your Cards");
		Label dCardsLbl = setLabel("Dealer's Cards");
		Label poolLbl = new Label("Pool", poolTxt);
			poolLbl.setContentDisplay(ContentDisplay.BOTTOM);
		
		//flowpanes for the image views
			//player cards
		FlowPane pCardFpane = new FlowPane(Orientation.HORIZONTAL, 5, 15) ;	
			pCardFpane.setAlignment(Pos.CENTER);
			//dealer cards
		FlowPane dCardFpane = new FlowPane(Orientation.HORIZONTAL, 5, 15 );	
			dCardFpane.setAlignment(Pos.CENTER);
			
			//add the card images to the flow panes
			for(int i = 0; i < dCardImgs.size(); i++){
				//if the boolean is true and it is on the second element in the list
				if(!revealDealer && i == 1){
					//the card should be hidden
					dCardFpane.getChildren().add(backImg);
				}
				//otherwise show the image
				else{
				dCardFpane.getChildren().add(dCardImgs.get(i));
				}
			}
			
			//add the image to the player card pane
			for(ImageView element: pCardImgs){
				pCardFpane.getChildren().add(element);
			}
			//if the boolean is false then the second image in the dealer's list should be shown
			if(revealDealer){
				dCardImgs.get(1).setImage(dCardImgs.get(1).getImage());
			}

			
	//vboxes for the card sets
		//vbox for the player cards
		VBox pCardVbox = new VBox(20);		
			pCardVbox.setAlignment(Pos.CENTER);	
			pCardVbox.getChildren().add(pCardsLbl);
			pCardVbox.getChildren().add(pCardFpane);
			pCardVbox.getChildren().add(pScoreTxt);
		//vbox for the dealer cards
		VBox dCardVbox = new VBox(20);		
			dCardVbox.setAlignment(Pos.CENTER);
			dCardVbox.getChildren().add(dCardsLbl);
			dCardVbox.getChildren().add(dCardFpane);		
		//vbox for the buttons
		VBox buttonVbox = new VBox(20);
			buttonVbox.setAlignment(Pos.CENTER);	
			buttonVbox.getChildren().add(hitBt);
			buttonVbox.getChildren().add(standBt);
			buttonVbox.getChildren().add(quitBt);
		
		//grid pane
		GridPane handGridPane = new GridPane();
			handGridPane.setGridLinesVisible(false);
			handGridPane.setAlignment(Pos.CENTER);
			handGridPane.setPadding(new Insets(20, 20, 20 ,20));
			//title
			handGridPane.add(handTitle, 1, 0);
			
			//Hands and winnings 
			handGridPane.add(handsLbl, 0, 1);
			GridPane.setHalignment(handsLbl, HPos.CENTER);
			handGridPane.add(winningsLbl, 2, 1);
			GridPane.setHalignment(winningsLbl, HPos.CENTER);
			
			//YourCardVbox, poolLbl, and DealerCarVbox
			handGridPane.add(pCardVbox, 0, 2);
			GridPane.setHalignment(pCardVbox, HPos.CENTER);
			handGridPane.add(poolLbl, 1, 2);
			GridPane.setHalignment(poolLbl, HPos.CENTER);
			handGridPane.add(dCardVbox, 2, 2);
			dCardVbox.getChildren().add(dScoreTxt);
			GridPane.setHalignment(dCardVbox, HPos.CENTER);
			
			//Button vbox
			handGridPane.add(buttonVbox, 1, 3);
			GridPane.setHalignment(buttonVbox, HPos.CENTER);
			handGridPane.setStyle("-fx-background-color: #D8CACB;");
			
		//create the scene
		Scene handScene = new Scene(handGridPane, 700, 600);
		
		//place the scene into the stage
		primaryStage.setScene(handScene);
		primaryStage.show();

	//handlers for the buttons
		//Hit button
		hitBt.setOnAction(ActionEvent -> hit(primaryStage, game));
		//stand button
		standBt.setOnAction(ActionEvent -> stand(primaryStage, game));
		
		//if reveal dealer is true
		if(revealDealer){
			//change stand button text
			standBt.setText("Continue");
			
			//make the hit button useless 
			hitBt.setOnAction(
					new EventHandler<ActionEvent>(){
				@Override
				public void handle(ActionEvent e){
					//don't do anything.
					;
				}
			});
			
			//lessen the opacity of the hit button to indicate the change
			hitBt.setOpacity(.5);
			
			//the player went over 21 or the player had a lower score, the dealer wins. the dealer also wins if they have 21 and the player does not
			if((game.getPScore() > 21) || (game.getDScore() > game.getPScore() && game.getDScore() < 22) || (game.getDScore() == 21 && game.getPScore() != 21)){
				//increase the loss counter
				game.setLosses(game.getLosses() + 1);
				//alter the stand button
				standBt.setOnAction(e->createFinalScene(primaryStage, game, "d"));
			}
			//the dealer went over 21 or the player has the higher score, the player wins
			else if(game.getDScore() > 21 || game.getPScore() > game.getDScore() || game.getPScore() == 21){
				//increment the win counter
				game.setWins(game.getWins() + 1);
				//add the pool to the player's winnings
				game.setWinnings(game.getWinnings() + game.getBetPool());
				//alter the stand button
				standBt.setOnAction(e -> createFinalScene(primaryStage, game, "p"));
			}
			//the dealer and the player had the same score
			else if(game.getPScore() == game.getDScore()){
				//increment the tie counter
				game.setTies(game.getTies() + 1);
				//alter the stand button
				standBt.setOnAction(e ->createFinalScene(primaryStage, game, "t"));
			}
		}
		//quit button
		quitBt.setOnAction(e ->quit(primaryStage, game));
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(hitBt);	
		fireOnEnter(standBt);
		fireOnEnter(quitBt);
	}
	
	/** method that creates the final scene*/
	static void createFinalScene(Stage primaryStage, BlackJackGame game, String winCond){
		//discard the cards in play
		game.discard();
	//create the UI elements
		//Text
		String winConText = " ";
		//player won
			if(winCond.equals("p")){
				winConText = "You won!";
			}
			//dealer won
			else if(winCond.equals("d")){
				winConText = "Sorry, better luck next time!";
			}
			//a tie
			else{
				winConText = "A tie!!";
			}
			//don't add the score to high scores if it is less than 1
			if(game.getWinnings() > 0){
				if(game.compareScore(game, bHighScoreFile)){
					winConText += " You have a top ten score!";
				}
			}
			
		//text
		Text finalTitle = new Text("Hand Complete!");
			finalTitle.setFont(Font.font("Abyssinica SIL",24));
			finalTitle.setFill(Color.color(.21, .09, .23));
		Text winCondition = new Text(winConText);								//Text object to hold the winner
			winCondition.setFont(Font.font("Abyssinica SIL", 16));
			winCondition.setFont(new Font(16));
			winCondition.setFill(Color.color(.21, .09, .23));
		Text winsTxt = new Text(Integer.toString(game.getWins()));					//text object to hold the number of wins
			winsTxt.setFont(Font.font("Abyssinica SIL", 16));
			winsTxt.setFill(Color.color(.21, .09, .23));
		Text lossesTxt = new Text(Integer.toString(game.getLosses()));				//text object to hold the number of losses
			lossesTxt.setFont(Font.font("Abyssinica SIL", 16));
			lossesTxt.setFill(Color.color(.21, .09, .23));
		Text tiesTxt= new Text(Integer.toString(game.getTies()));						//text object to hold the number of ties
			tiesTxt.setFont(Font.font("Abyssinica SIL", 16));
			tiesTxt.setFill(Color.color(.21, .09, .23));
		Text winningsTxt = new Text("$" +Integer.toString(game.getWinnings()));		//text object to hold the players total winnings
			winningsTxt.setFont(Font.font("Abyssinica SIL", 16));
			winningsTxt.setFill(Color.color(.21, .09, .23));
			
		//label
		Label winsLbl = setLabel("Wins", winsTxt);
			winsLbl.setContentDisplay(ContentDisplay.BOTTOM);
		Label lossesLbl = setLabel("Losses", lossesTxt);
			lossesLbl.setContentDisplay(ContentDisplay.BOTTOM);
		Label tiesLbl = setLabel("Ties", tiesTxt);
			tiesLbl.setContentDisplay(ContentDisplay.BOTTOM);
		Label winningsLbl = setLabel("Winnings", winningsTxt);
			winningsLbl.setContentDisplay(ContentDisplay.BOTTOM);
			
		//hbox for the labels
		HBox statsHbox = new HBox(20);
			statsHbox.getChildren().add(winsLbl);
			statsHbox.getChildren().add(lossesLbl);
			statsHbox.getChildren().add(tiesLbl);
			statsHbox.getChildren().add(winningsLbl);
		Label statsLbl = setLabel("Your Current Stats", statsHbox);
			statsLbl.setContentDisplay(ContentDisplay.BOTTOM);
			
		//Button 
		Button shuffleBt = setButton("Shuffle");
		Button nextRoundBt = setButton("Start the\nNext Round");
		Button backBt = setButton("End Game and\nReturn to Menu");
		
		//vbox for the buttons
		VBox btVbox = new VBox(20);
			btVbox.setAlignment(Pos.CENTER);
			btVbox.getChildren().add(shuffleBt);
			btVbox.getChildren().add(nextRoundBt);
			btVbox.getChildren().add(backBt);
		//vbox for the whole thing
		VBox finalVbox = new VBox(30);
			finalVbox.setAlignment(Pos.CENTER);
			finalVbox.getChildren().add(finalTitle);
			finalVbox.getChildren().add(winCondition);
			finalVbox.getChildren().add(statsLbl);
			finalVbox.getChildren().add(btVbox);
			finalVbox.setStyle("-fx-background-color: #D8CACB;");
		primaryStage.setScene(new Scene(finalVbox, 900, 700));
		primaryStage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(shuffleBt);	
		fireOnEnter(nextRoundBt);
		fireOnEnter(backBt);
	//Event handlers for the buttons
		//Event handler for the shuffle Button 
		shuffleBt.setOnAction(e -> {game.shuffle(); winCondition.setText("The deck was shuffled.");});
		//event handler for the next round button 
		nextRoundBt.setOnAction(e->setUpNextRound(primaryStage, game, winCondition));
		//event handler for the back button, which ends the game.
		backBt.setOnAction(e->quit(primaryStage, game));
	}
	
	
	 /* **************************************************************************************************************************** *
	 * Methods that deal with tasks related to specific events in the game *
	 * **************************************************************************************************************************** */
	
	/**Method that gets the number of decks the user wants to use and then starts the game */
	static void getBet(TextField betTF, BlackJackGame game){
		int bet = 0;
		//check that the bet is a double
		try{
			//get the text from the text field
			String s = betTF.getText();
			//parse it to an integer
			bet = Integer.parseInt(s);
		}
		catch(Exception ex){
			//Create a border pane
			BorderPane popUp = new BorderPane();
				popUp.setStyle("-fx-background-color: #BFA6A3;");
				popUp.setCenter(new Text("Please enter a monetary value"));
			//place the border pane into a scene and place the scene into a new stage
			Scene popUpScene = new Scene(popUp, 300, 150);		
			Stage popUpStage = new Stage();	
			popUpStage.setTitle("Bet Error");
			popUpStage.setScene(popUpScene);
			popUpStage.show();
		}
		
		//if the string can be parsed into an integer
		if(bet < 1 || bet > 100){
			//Create a border pane
			BorderPane popUp = new BorderPane();
				popUp.setStyle("-fx-background-color: #BFA6A3;");
				popUp.setCenter(new Text("Enter a bet between 1 and 100"));
			//place the border pane into a scene and place the scene into a new stage
			Scene popUpScene = new Scene(popUp, 300, 150);		
			Stage popUpStage = new Stage();	
			popUpStage.setTitle("Bet Error");
			popUpStage.setScene(popUpScene);
			popUpStage.show();
		}
		else{
			game.setBetPool(bet);
		}
		
	}
	
	/** Method that gets the player a new card and then re-makes the scene*/
	static void hit(Stage primaryStage, BlackJackGame game){
		boolean reveal = false;
		//Get the player a new card
		pCardImgs.add(new ImageView(game.drawCard("player")));
		//if the player goes over 21 the dealer wins
		if(game.getPScore() > 21){
			//reveal the dealer's second card
			reveal = true;
		}
		//either way
			//call the create hand scene method 
		createHandScene(primaryStage, game, reveal);	
	}
	
	/** Method that ends the hand and gets the dealer new cards if needed. it then re-makes the scene*/
	static void stand(Stage primaryStage, BlackJackGame game){
		//When the player chooses to stand the dealer must draw a card as long as their score is less than 17
		do {
			dCardImgs.add(new ImageView(game.drawCard("dealer")));
		}while(game.getDScore() < 17);
		//call the create hand scene method, dealer's cards should all be visible
		createHandScene(primaryStage, game, true);	
	}
	
	/**Method that prepares the next round of play */
	static void setUpNextRound(Stage primaryStage, BlackJackGame game, Text winCondition){
		//set the scores to 0
		game.setPScore(0);
		game.setDScore(0);
		//bet should be set to 0
		game.setBetPool(0);
		
		//if there are a quarter of the cards left in the deck, shuffle the deck, let the user know 
		if(game.getCardsDealt() == (game.cards.length / 4)){
			game.shuffle();
			winCondition.setText("The deck was nearly empty, it was shuffled.");
		}
		
		//the player and dealer card lists should be cleared
		pCardImgs.clear();
		dCardImgs.clear();
		//call the bet scene method
		betScene(primaryStage, game);
	}
	
	/** Method that exits the application completely*/
	static void exit(){
	//create the UI elements
		//Text
		Text txt = new Text("Are you sure?");			//text object for the question
			txt.setTextAlignment(TextAlignment.CENTER);
			txt.setFont(Font.font("Abyssinica SIL", 16));
			txt.setFill(Color.color(.21, .09, .23));
			
		//Button
		Button yesBt =  setButton("Yes");
			yesBt.setMinWidth(50);
		Button noBt = setButton("No");
			noBt.setMinWidth(50);
			
		//hbox for the buttons
		HBox hBox= new HBox(20);
			hBox.setAlignment(Pos.CENTER);	
			hBox.getChildren().add(yesBt);
			hBox.getChildren().add(noBt);
		//vbox for the text and the buttons
		VBox vBox= new VBox(35);
			vBox.setAlignment(Pos.CENTER);		
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);

		//Create a border pane
		BorderPane exitPane = new BorderPane();
			exitPane.setStyle("-fx-background-color: #BFA6A3;");
			exitPane.setCenter(vBox);
		//create the new scene
		Scene scene = new Scene(exitPane, 200, 150);		
		Stage stage = new Stage();
		stage.setTitle("Exit");
		stage.setScene(scene);
		//Display the Stage
		stage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(yesBt);	
		fireOnEnter(noBt);
		//Event handlers
		yesBt.setOnAction(e -> {
			//make sure the files are closed
			try{
				//file 1
				bGameDataFileIn.close();
				//file 2
				bHighScoreFileIn.close();
				//file 3
				bHighScoreFileOut.close();
				//file 4
				bGameDataFileOut.close();
			}
			catch(Exception ex){
				System.out.print("no files were open");
			}
			//close the application
			Platform.exit();
		});
		//if the answer is no, close the new stage
		noBt.setOnAction(e -> stage.close());

	}
	
	/** Method that returns the user to the main menu. it writes the the total score at the time to the file */
	static void quit(Stage primaryStage, BlackJackGame game){
	//create the UI elements
		//Text
		Text txt = new Text("Are you sure?");					//text object for the question
			txt.setTextAlignment(TextAlignment.CENTER);
			txt.setFont(Font.font("Abyssinica SIL", 16));
			txt.setFill(Color.color(.21, .09, .23));
			
		//Button
		Button yesBt =  setButton("Yes");
			yesBt.setMinWidth(50);
		Button noBt = setButton("No");
			noBt.setMinWidth(50);
		
		//hbox for the buttons
		HBox hBox= new HBox(20);
			hBox.getChildren().add(yesBt);
			hBox.getChildren().add(noBt);
			hBox.setAlignment(Pos.CENTER);
		//vbox for the text and buttons
		VBox vBox= new VBox(35);
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);
			vBox.setAlignment(Pos.CENTER);
		
		//Create a border pane
		BorderPane exitPane = new BorderPane();
			exitPane.setStyle("-fx-background-color: #BFA6A3;");
			exitPane.setCenter(vBox);
			
		//create the new scene
		Scene scene = new Scene(exitPane, 200, 150);		
		Stage stage = new Stage();
		stage.setScene(scene);
		stage.setTitle("Quit");
		//Display the Stage
		stage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(yesBt);	
		fireOnEnter(noBt);
		//Event handlers
		yesBt.setOnAction(e -> {
			try{
				//write the game data to the file
				writeGameData(game);
				//try to close the file
				bGameDataFileOut.close();
			}
			catch(Exception ex){
				System.out.print("The file was not open");
			}
			//close this stage
			stage.close();		
			//return to the menu
			getMenu(primaryStage);
			});
		
		//the answer was no, close the new stage
		noBt.setOnAction(e -> stage.close());
	}	
	
	
	/** Method exits the game completely while it is being played. It writes the current 
	 * score to the file and makes sure that the files are closed*/
	static void hardQuit(Stage primaryStage, BlackJackGame game){
	//create the UI elements
		//Text
		Text txt = new Text("Are you sure?"						//text object for the question
				+ "\nYou will quit\nthe entire game.");
			txt.setTextAlignment(TextAlignment.CENTER);
			txt.setFont(Font.font("Abyssinica SIL", 14));
			txt.setFill(Color.color(.21, .09, .23));
			
		//Button
		Button yesBt =  setButton("Yes");
			yesBt.setMinWidth(50);
		Button noBt = setButton("No");
			noBt.setMinWidth(50);
		
		//hbox for the buttons
		HBox hBox= new HBox(20);
			hBox.getChildren().add(yesBt);
			hBox.getChildren().add(noBt);
			hBox.setAlignment(Pos.CENTER);
		//vbox for the text and buttons
		VBox vBox= new VBox(35);
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);
			vBox.setAlignment(Pos.CENTER);
		
		//Create a border pane
		BorderPane exitPane = new BorderPane();
			exitPane.setStyle("-fx-background-color: #BFA6A3;");
			exitPane.setCenter(vBox);
		//create the new scene
		Scene scene = new Scene(exitPane, 200, 150);		
		Stage stage = new Stage();
		stage.setScene(scene);
		stage.setTitle("Exit");
		//Display the Stage
		stage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(yesBt);	
		fireOnEnter(noBt);
		//Event handlers
		yesBt.setOnAction(e -> {
			try{
				//write the game data to the file
				writeGameData(game);
				//try to close the file
				bGameDataFileOut.close();
			}
			catch(IOException ex){
				System.out.print("The file was not open");
			}
			//close this stage
			stage.close();
			//close the application
			Platform.exit();
			});
		
		//the answer was no, close the new stage
		noBt.setOnAction(e -> stage.close());
	}	
	
	/** Method that writes the data from the game session to the file */
	static void writeGameData(BlackJackGame game){
		//create the file writer
		bGameDataFileOut = GameData.createFileWriter(bGameDataFile, bGameDataFileOut, false);	
	//append the game to the game Data File
		//append the name and date
		games.updateUserRecord(game.getName(), (game.getDate() + "\n"));
		//append the winnings
		games.updateUserRecord(game.getName(),  ("Winnings: $" + game.getWinnings() + "\n"));
		//append the wins
		games.updateUserRecord(game.getName(),  ("Wins: " + game.getWins() + "\n"));
		//append the losses		
		games.updateUserRecord(game.getName(),  ("Losses: " + game.getLosses() + "\n"));
		//append the ties
		games.updateUserRecord(game.getName(),  ("Ties: " + game.getTies() + "\n"));
		//append the divider 
		games.updateUserRecord(game.getName(), GameData.gameDivider);
		
		games.overwriteGameData(bGameDataFileOut);
	}
	
		/** method that handles firing the buttons when enter is pressed*/
	static void fireOnEnter(Button b){
		b.setOnKeyPressed(e -> {
			if(e.getCode().equals(KeyCode.ENTER) && b.isFocused())
				b.fire();
		});
	}
	
	/* ************************************************************************************************************ *
	 * Methods that set up the appearance of specific node types *
	 * ************************************************************************************************************ */
	
	/** Method that sets up the styles appearance of the button*/
	static Button setButton(String s){
		Button b = new Button(s);
		b.setFont(Font.font("Abyssinica SIL", 16));
		b.setStyle("-fx-background-color: #AD6C82; -fx-border-color: #AD6C82; -fx-text-fill: #F3F1E2;"
				+ "-fx-border-radius: 15,15,15,15;");
		b.setMinWidth(100);
		b.setMinHeight(25);
		b.setFocusTraversable(true);
		//set drop shadow
		 DropShadow dropShadow = new DropShadow();
			 dropShadow.setRadius(4.0);
			 dropShadow.setOffsetX(2.0);
			 dropShadow.setOffsetY(2.0);
			 dropShadow.setColor(Color.color(0.026, 0.108, 0.120)); 
			 b.setEffect(dropShadow);
		return b;
	}
	
	/** Method that sets up the styles appearance of the textField*/
	static TextField setTextField(Boolean edit){
		TextField textF = new TextField();
		textF.setStyle("-fx-background-color: #E1ECFC; ");
		textF.setFont(Font.font("Abyssinica SIL", 14));
		textF.setEditable(edit);
		return textF;
	}
	
	/** Method that sets up the styles appearance of the textFiled*/
	static TextField setTextField(String s, Boolean edit, int cols){
		TextField textF = new TextField(s);
		textF.setStyle("-fx-background-color: #E1ECFC; ");
		textF.setFont(Font.font("Abyssinica SIL"));
		textF.setEditable(edit);
		textF.setPrefColumnCount(cols);
		return textF;
	}
	
	/** Method that sets up the styles appearance of the label*/
	static Label setLabel(String s, Node n){
		Label lbl = new Label(s, n);
		lbl.setStyle("-fx-line-height: 2em;");
		lbl.setFont(Font.font("Abyssinica SIL", 16));
		lbl.setTextFill(Color.color(.21, .09, .23));
		return lbl;
	}
	
	/** Method that sets up the styles appearance of the label*/
	static Label setLabel(String s){
		Label lbl = new Label(s);
		lbl.setStyle("-fx-line-height: 2em;");
		lbl.setFont(Font.font("Abyssinica SIL", 16));
		lbl.setTextFill(Color.color(.21, .09, .23));
		return lbl;
	}
}
