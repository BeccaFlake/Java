/*
Rebecca Flake
4-9-2018 Through 4-30-2018 
Java
Version 8
Includes: 
   Java-
	File and FileWriter classes
	Scanner class
	LinkedList class
	Calendar, Gregorian Calendar class
	Linked List class
	ThreadLocalRandom class
   JavaFx-
	Image class
   Images (all .bmp unless otherwise specified)-
   	2Clubs, 3Clubs, 4Clubs, 5Clubs, 6Clubs, 7Clubs, 8Clubs, 9Clubs, 10Clubs, QueenClubs, KingClubs, JackClubs, AceClubs
   	2Spades, 3Spades, 4Spades, 5Spades, 6Spades, 7Spades, 8Spades, 9Spades, 10Spades, QueenSpades, KingSpades, JackSpades, AceSpades
   	2Hearts, 3Hearts, 4Hearts, 5Hearts, 6Hearts, 7Hearts, 8CHearts, 9Hearts, 10Hearts, QueenHearts, KingHearts, JackHearts, AceHearts
   	2Diamonds, 3Diamonds, 4Diamonds, 5Diamonds, 6Diamonds, 7Diamonds, 8Diamonds, 9Diamonds, 10Diamonds, QueenDiamonds, KingDiamonds, JackDiamonds, AceDiamonds
   	cardBack.jpg
   Files
   	gameData.txt
   	highScore.txt
COP2552.001
Final Project
This program allows the user to play a game of Blackjack with a graphical user interface.  The user can also view instructions on how to play, View the top ten scores 
of all time, and view the game data from the 10 most recently played games.
 */
package application;

import java.io.File;
import java.io.FileWriter;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Scanner;
import javafx.scene.image.Image;

class BlackJackGame {
	//global variables
	private int winnings,									//variable to hold the player's total winnings for the duration of the game session
				 betPool,									//variable to hold the sum of the player and dealer's bets
				 pScore,										//variable to hold the sum of the player's card values
			     dScore,										//variable to hold the sum of the dealer's card values
				   wins,										//variable to hold the number of wins
				  losses,										//variable to hold the number of losses
				    ties,										//variable to hold the number of ties
	        roundCounter,									//variable to hold the number of hands played
	       	  cardsDealt,									//variable to hold the number of cards that have been removed from the deck. 
	       	  numDecks;										//variable to hold the number of decks to use
	
	private String name,									//variable to hold the player's name
					date;									//variable to hold the date on which the game is/was played	
		
	Card[] cards;												//Array of card objects

	//create the list for the in play cards
	private LinkedList<Card> inPlayCards = new LinkedList<Card>();
	//create the list for the discarded cards
	private LinkedList<Card> discardedCards = new LinkedList<Card>();
	
	//File Variables. They are all static because they do not depend on the instance
	Scanner highScoreFileIn;
	Scanner highScoreFileIn2;
	Scanner gameDataFileIn;
	Scanner gameDataFileIn2;
	FileWriter highScoreFileOut;
	FileWriter gameDataFileOut;
	
	
	//no-arg constructor
	public BlackJackGame(){
		//set the integer variables to zero
		winnings = 0;									
		betPool = 0;	
	    pScore = 0;	
	    dScore = 0;	
	    wins = 0;
	    losses = 0;
	    ties = 0;
	    roundCounter = 0;
	    cardsDealt = 0;	
	    //number of decks is set to 1
	    numDecks = 1;
	    
		//set name to a a filler string
		name = "???";		
		
		//create the array for the card deck, the length of which is 52 multiplied by the number of decks
		final int CARDNUM = 52 * numDecks;
		cards = new Card[CARDNUM];
		
		//get the current date
		Calendar calendar = new GregorianCalendar();					//a Gregorian calendar object which we will use to get the current date
		int day  = calendar.get(Calendar.DATE);						//variable that will hold the current day of the month
		int month = calendar.get(Calendar.MONTH) +1;					//variable that will hold the current month. because the parameter is 0 based, 1 is added to it
		int year = calendar.get(Calendar.YEAR);						//variable that will hold the current year in yyyy format
		date = (month + "/" + day + "/" + year);							//variable that will hold the date string in m[m]/d[d]/yyyy format	
	}
	
	
	//constructor which accepts the given name 
	public BlackJackGame(String n, int decks){
		//set the integer variables to zero
		winnings = 0;									
		betPool = 0;	
	    pScore = 0;	
	    dScore = 0;	
	    wins = 0;
	    losses = 0;
	    ties = 0;
	    roundCounter = 0;
	    cardsDealt = 0;
	    //set the number of decks to the parameter given to the constructor 
	    numDecks = decks;
	    
		//set name to the given string
		name = n;	
		
		//create the array for the card deck, the length of which is 52 multiplied by the number of decks
		final int CARDNUM = 52 * numDecks;
		cards = new Card[CARDNUM];
		
		//get the current date
		Calendar calendar = new GregorianCalendar();					//a Gregorian calendar object which we will use to get the current date
		int day  = calendar.get(Calendar.DATE);						//variable that will hold the current day of the month
		int month = calendar.get(Calendar.MONTH) +1;					//variable that will hold the current month. because the parameter is 0 based, 1 is added to it
		int year = calendar.get(Calendar.YEAR);						//variable that will hold the current year in yyyy format
		date = (month + "/" + day + "/" + year);							//variable that will hold the date string in m[m]/d[d]/yyyy format	
	}
	
	/* **************************** *
	 * Getter Methods *
	 * ************************** */
	/** Method that gets the winning variable*/
	 int getWinnings(){ return winnings; }	
	 
	/** Method that gets the bet poor variable*/
	 int getBetPool(){ return betPool;}	
	 
	/** Method that gets the play score variable*/	 
	 int getPScore(){ return pScore;}	
	 
	 /** Method that gets the dealer score variable*/	 
	 int getDScore(){ return dScore;}	
	 
	 /** Method that gets the win variable*/	 
	 int getWins(){ return wins;}	
	 
	 /** Method that gets the loss variable*/	 
	 int getLosses(){ return losses;}	
	 
	 /** Method that gets the tie variable*/	 
	 int getTies(){ return ties;}		
	 
	 /** Method that gets the round counter variable*/	 
	 int getRoundCounter(){ return roundCounter;}
	 
	 /** Method that gets the cards dealt variable*/	 
	 int getCardsDealt(){ return cardsDealt;}	
	 
	 /** Method that gets the number of decks variable*/	 
	 int getNumDecks(){ return numDecks;}		
	 
	 /** Method that gets the name variable*/	 
	 String getName(){ return name;}	
	 
	 /** Method that gets the date variable*/	  
	 String getDate(){ return date;}								
	
	 /* **************************** *
	 * Setter Methods *
	 * ************************** */
	/** Method that gets the winning variable*/
	 void setWinnings(int w){winnings = w; }	
	 
	/** Method that gets the bet poor variable*/
	 void setBetPool(int bp){betPool = bp;}	
	 
	/** Method that gets the play score variable*/	 
	 void setPScore(int ps){pScore = ps;}	
	 
	 /** Method that gets the dealer score variable*/	 
	 void setDScore(int ds){dScore = ds;}	
	 
	 /** Method that gets the win variable*/	 
	 void setWins(int win){wins = win;}	
	 
	 /** Method that gets the loss variable*/	 
	 void setLosses(int loss){losses = loss;}	
	 
	 /** Method that gets the tie variable*/	 
	 void setTies(int tie){ties = tie;}		
	 
	 /** Method that gets the round counter variable*/	 
	 void setRoundCounter(int round){roundCounter = round;}
	 
	 /** Method that gets the cards Dealt variable*/	 
	 void setCardsDealt(int Dealt){ cardsDealt = Dealt;}	
	 
	 /** Method that gets the number of decks variable*/	 
	 void setNumDecks(int num){numDecks = num;}		
	 
	 /** Method that gets the name variable*/	 
	 void setName(String n){name = n;}	
	 
	 /** Method that gets the date variable*/	  
	 void setDate(String d){date = d;}								

	
	/* ***************************************************************************** *
	 * Methods that deal with the decks of cards *
	 * **************************************************************************** */
	
	/** Method that creates the deck of cards*/
	void createDeck(){
		int i = 0; 					//integer variable that holds the number for the cards it starts at 0
		//create the number of decks the user wanted
		for(int d = 0; d < numDecks; d++){
		//create each suite 
			//create the heart suite
			i = createSuite("Hearts", i);
			//create the spade suite
			i = createSuite("Spades", i);
			//create the diamond suite
			i = createSuite("Diamonds", i);
			//create the club suite 
			i = createSuite("Clubs", i);
		}
	}
	
	/** Method that creates the suite of cards. it returns the current card number */
	int createSuite(String suite, int i){
		//create the non-face cards
			//non-face cards are 2-10, so the counter starts at 2 and stops before it reaches 11
		for(int c = 2; c < 11; c ++){
			//create the image path string, which is the card number and the suite
			String imgPath = c + suite;
			//create the card object for the card reference variable at the current index in the cards array
			cards[i] = new Card(suite, c, "non-face", imgPath);
			//increment the total card counter
			i++;
		}
		
		//create the queen
			//create the card object for the card reference variable at the current index in the cards array
			cards[i] = new Card(suite, 10, "face", ("Queen" + suite));
			//increment the total card counter
			i++;
		//create the king
			//create the card object for the card reference variable at the current index in the cards array
			cards[i] = new Card(suite, 10, "face", ("King" + suite));
			//increment the total card counter
			i++;		
		//create the jack
			//create the card object for the card reference variable at the current index in the cards array
			cards[i] = new Card(suite, 10, "face", ("Jack" + suite));
			//increment the total card counter
			i++;		
		//create the ace. It is initialized to a value of 11, which will change later based on the circumstances. I'm also counting it as a face card even though it has a different value
			//create the card object for the card reference variable at the current index in the cards array
			cards[i] = new Card(suite, 11, "ace", ("Ace" + suite));
			//increment the total card counter
			i++;	
		//return the card counter
		return i;
	} 
	
	/** method that gets the random card from the array, adds it to the list of in use cards,
	 * changes the user's score, and then returns the corresponding image for the card to be used by the GUI*/
	Image drawCard(String person){
		//the card is initialized to the default image
		Image image = new Image("/cardBack.jpg");
		boolean invalidIndex = true;
		
		//while the boolean is true
		while(invalidIndex){
			//get a random number 0-52 for the index
			int low = 0;
			int high = cards.length;
			//Get a random int using Thread Local Random 
			int randIndex = ThreadLocalRandom.current().nextInt(low, high);
			
			//if there is a card at the index
			if(!cards[randIndex].getCardInUse() && randIndex < high){
				//add it to the end of the list of in play cards
				inPlayCards.addLast(cards[randIndex]);
				//set inUse to true
				cards[randIndex].setCardInUse(true);
				//set usedBy to the person
				cards[randIndex].setCardUsedBy(person);
			
			//add the card value to the person's score	
				if (person == "player"){
					//if the score is currently greater than 10, an ace will be one
					if(cards[randIndex].getCardType().equals("ace") && pScore > 10){
						cards[randIndex].setCardValue(1);
					}
					//if the score is currently less than 10, an ace will be eleven				
					else if(cards[randIndex].getCardType().equals("ace") && pScore < 10) {
						cards[randIndex].setCardValue(11);
					}
					//add the value of the card to the player's score
					pScore += cards[randIndex].getCardValue();
				}
				else{
					//if the score is currently greater than 10, an ace will be one
					if(cards[randIndex].getCardType().equals("ace") && dScore > 10){
						cards[randIndex].setCardValue(1);
					}
					//if the score is currently less than 10, the ace will be eleven
					else if(cards[randIndex].getCardType().equals("ace") && dScore < 10) {
						cards[randIndex].setCardValue(11);
					}
					//add the value of the card to the dealer's score
					dScore += cards[randIndex].getCardValue();
				}
	
				//get the image for the card
				image = cards[randIndex].getCardImage();
				//boolean is false
				invalidIndex = false;
			}	
			//if there is not a card at the index
			else{
				//boolean is true
				invalidIndex = true;
			}
		}
		//increment the number of cards that have been Dealt
		cardsDealt++;
		//return the image
		return image;
	}
	
	/** method that swaps the cards from the in use list to the discarded list */
	void discard(){
		//copy the contents of the in play list to the discarded list
		for(Card element: inPlayCards){
			discardedCards.add(element);
		}
		//clear the contents from the in play list
		inPlayCards.clear();
		//set the discarded boolean for the elements to true
		for (Card s: discardedCards){
			s.setCardDiscarded(true);
		}
	}
	
	/** method that 'shuffles the deck' */
	void shuffle(){
		//
		for(int j = 0; j < cards.length; j++){
			cards[j].setCardInUse(false); 
			cards[j].setCardUsedBy(" ");
		}
		//clear the two lists
		inPlayCards.clear();
		discardedCards.clear();
	}
	
	/* **************************************************************************************************** *
	 * Methods that do the administrative tasks for the game *
	 * *************************************************************************************************** */
	
	/**method that checks if the game score is higher than the lowest score in the high score file then replaces it if needed */
	boolean compareScore(BlackJackGame game, File highScoreFile){
		boolean newScore = false;									//a variable to hold the boolean value
		final int ROWS = 10;
		final int COLS = 3;
		//create the array to hold the input from the file
		String[][] inputArray = new String[ROWS][COLS];

		//create the input scanner 
		Scanner inputFile = GameData.createFileScanner(highScoreFile, highScoreFileIn);
		//a for loop that reads the values from the file into the array
		int scoresInFile = 0;
		if(highScoreFile.length() != 0){
			for(int i = 0; i < ROWS; i++){
				if(inputFile.hasNextLine()){
						//place the score in the array
						String fileLine  = inputFile.nextLine();
						//break the line up into tokens
						String[] tokens = fileLine.split("\\s");
						//put the tokens into the array elements
						inputArray[i][0] = tokens[0];
						//place the name in the array
						inputArray[i][1] = tokens[1];
						//place the date in the array
						inputArray[i][2] = tokens[2];
						//increment the lines in file counter
						scoresInFile++;
				}
			}
			//cast the score in the last row of the array (the lowest score) to an integer so it can be compared to the game score
			//if there are not yet 10 scores in the file
			if(scoresInFile < ROWS){
				//add the new score to the inputArray
				inputArray[scoresInFile][0] = Integer.toString(game.winnings);
				//add the name
				inputArray[scoresInFile][1] = game.name;
				//add the date
				inputArray[scoresInFile][2] = game.date;
				//sort the array
				inputArray = sortHighScoreFileArray(inputArray, (scoresInFile+1), COLS);
				//create the output file
				highScoreFileOut = GameData.createFileWriter(highScoreFile, highScoreFileOut, false);
				//re-write the file
				for(int i = 0; i < (scoresInFile+1); i++){
					String outputString  = inputArray[i][0] + " " +  inputArray[i][1] + " " +  inputArray[i][2] + "\n";
					GameData.writeToFile(highScoreFileOut, outputString);
				}
				newScore = true;
			}
			
			//there are 10 scores in the file
			else{
				int lowest = Integer.parseInt(inputArray[ROWS-1][0]);
				//if the game score is greater than or equal the lowest score from the file
				if(game.winnings >= lowest){
				//replace the values in the last row of the array
					//replace the score
					inputArray[ROWS - 1][0] = Integer.toString(game.winnings);
					//replace the name
					inputArray[ROWS - 1][1] = game.name;
					//replace the date
					inputArray[ROWS - 1][2] = game.date;
					//sort the array
					inputArray = sortHighScoreFileArray(inputArray, scoresInFile, COLS);
					//create the output file
					highScoreFileOut = GameData.createFileWriter(highScoreFile, highScoreFileOut, false);
					//re-write the file
					for(int i = 0; i < ROWS; i++){
						String outputString  = inputArray[i][0] + " " +  inputArray[i][1] + " " +  inputArray[i][2] + "\n";
						GameData.writeToFile(highScoreFileOut, outputString);
					}
					//set the boolean to true
					newScore = true;
				}
				//otherwise don't do anything
				else{;}	
			}
		}
		//there is no score in the file	
		else{
			//create the output file
			highScoreFileOut = GameData.createFileWriter(highScoreFile, highScoreFileOut, false);
			//write the score, name and date to the file.
			String highScoreOutputLine = game.winnings + " " + game.name + " " + game.date + "\n";			//string variable that holds the line with the high score, name, and date
			GameData.writeToFile(highScoreFileOut, highScoreOutputLine);	
			newScore = true;
		}
			//close the file
		try{
			highScoreFileOut.close();
		}
		catch(Exception ex){
			System.out.println("There was an error closing the file in the compare high score method");
		}
		//return the boolean		
		return newScore;	
   }
 	

	/** Method that sorts the scores from the high score file. It is private, as it is only used within this class */
	private String[][] sortHighScoreFileArray(String[][] fileArray, final int ROWS, final int COLS){
		String[] tempArray = new  String[COLS];
		//for each row in the array-1, working from the last row to the first
		for(int i = ROWS-1; i > 0; i--){
			//create the integer variables to be compared
			int score1= Integer.parseInt(fileArray[i][0]);						//integer variable to hold the score value from the current row
			int score2 = Integer.parseInt(fileArray[i-1][0]);						//integer variable to hold the score value from the 'next' row
			//if the score in the current row is greater than or equal to the score in the next row
			if(score1 >= score2){
				//place the values from the 'next' row in the temporary array
				tempArray[0] = fileArray[i-1][0];
				tempArray[1] = fileArray[i-1][1];
				tempArray[2] = fileArray[i-1][2];
				//place the values from the current row into the 'next' row
				fileArray[i-1][0]=fileArray[i][0];
				fileArray[i-1][1]=fileArray[i][1];
				fileArray[i-1][2]=fileArray[i][2];
				//place the values from the temp array into the current row. A swap has been made
				fileArray[i][0] = tempArray[0];
				fileArray[i][1] = tempArray[1];
				fileArray[i][2] = tempArray[2];
			}
			//otherwise do nothing
			else{;}
		}
		return fileArray;
	}
	
	//Empty main method
	static void main(String[] args) {
	}
	
	/* *********************************************************************************** * 
	 * End of methods in the BlackJackGame Class *
	 * ********************************************************************************** */
	
	/* ************************************ *
	 * Begin Nested Class *
	 * *********************************** */
	/** Class that creates the card objects */
	class Card {
		//global variables
		int value;							//variable for the card's numerical value
			
		boolean inUse,						//variable for whether the card is in use or not
				discarded;					//variable for whether the card has been discarded
		
		String usedBy,						//variable that holds the name of the individual that is using it
				 suite,						//variable to hold the suite that the card belongs to
				 type;						//variable to hold the type of card
		
		Image image;						//variable to hold the image of the card
		
		/** no-arg constructor */
		public Card (){
			value = 0;
		    inUse = false;
			discarded = false;
			usedBy = " ";
			suite = " ";
			type = " ";
			//default image
			image = new Image("image/cardBack.jpg");
		}
		
		/** constructor that accepts the suite, value, and type of card. It also accepts the card specific part of the image path */
		public Card(String s, int v, String t, String img){
			value = v;
		    inUse = false;
			discarded = false;
			usedBy = " ";
			suite = s;
			type = t;
			String path = "/" + img + ".bmp";
			image = new Image(path);
		}
		
		/* *************************** *
		 * Setter methods *
		 * ************************** */
		/** method that sets the value*/
		void setCardValue(int v){
			value = v;
		}
		/** method that sets the boolean for in use*/
		void setCardInUse(boolean u){
			inUse = u;
		}
		/** method that sets the boolean for discarded*/
		void setCardDiscarded(boolean d){
			discarded = d;
		}
		/** method that sets the value for used by*/
		void setCardUsedBy(String user){
			usedBy = user;
		}
		/** method that sets the suite */
		void setCardSuite(String s){
			suite = s;
		}
		/** method that sets the type */
		void setCardType(String t){
			type = t;
		}
		/** method that sets the image */
		void setCardImage(String img){
			String path = "/" + img + ".bmp";
			image = new Image(path);
		}
		
		/* **************************** *
		 * Getter methods *
		 * *************************** */
		/** method that gets the value*/
		int getCardValue(){
			return value;
		}
		/** method that gets the boolean for in use*/
		boolean getCardInUse(){
			return inUse;
		}
		/** method that gets the boolean for discarded*/
		boolean getCardDiscarded(){
			return discarded;
		}
		/** method that gets the value for used by*/
		String getCardUsedBy(){
			return usedBy;
		}
		/** method that gets the suite */
		String getCardSuite(){
			return suite;
		}
		/** method that gets the type */
		String getCardType(){
			return type;
		}
		/** method that gets the image */
		Image getCardImage(){
			return image;
		}
	}
	
}
