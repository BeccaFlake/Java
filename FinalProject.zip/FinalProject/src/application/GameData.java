/*
Rebecca Flake
4-20-2018 Through 4-30-2018 
Java
Version 8
Includes: 
   Java-
	File and FileWriter classes
	Scanner class
	LinkedList class
COP2552.001
Final Project
This class handles the file input and output methods, as well as creating objects for individual user's game data
 */

package application;

import java.io.File;
import java.io.FileWriter;
import java.util.LinkedList;
import java.util.Scanner;

public class GameData {
	//empty main method
	public static void main(String[] args) {
	}
	
	
	//linked list that will hold the player objects
	LinkedList<PlayerData> players; 
	//strings that act as dividers in the file
	static String playerDivider,
				   gameDivider;
	//the file name
	File fileName;
	
	
	//no arg constructor
	public GameData(){
		//set up the linked list
		players = new LinkedList<PlayerData>();
		/*Set the player divider to a string of 15 asterisks. */
		playerDivider = "***************\n";					
		/*Set the player divider to a string of 15 hyphens. */
		gameDivider = "---------------\n";
		//the file name
		fileName = new File("gameData.txt");
	}
	//constructor that accepts the name of the file
	public GameData(File file){
		//set up the linked list
		players = new LinkedList<PlayerData>();
		/*Set the player divider to a string of 15 asterisks.  */
		playerDivider = "***************\n";		
		/*Set the player divider to a string of 15 hyphens. */
		gameDivider = "---------------\n";
		//the file name
		fileName = file;
	}
	
	/* ***************************************************************************************************************
	 * Methods that deal with creating, writing to, and reading files *
	 ************************************************************************************************************** */
	
	/** Method that attempts to append a string to an output file and catches exceptions*/
	static void appendToFile(FileWriter outputFile, String outputString){
		//try to append to the file
		try{outputFile.append(outputString); }
		catch(Exception ex){System.out.println("Error writing data to file");}
	}

	/** Method that attempts to write a string to an output file and catches exceptions*/
	static void writeToFile(FileWriter outputFile, String outputString){
		//try to write to the file
		try{outputFile.write(outputString);}
		catch(Exception ex){System.out.println("Error writing data to file");}
	}
 
	/** Method that creates a new file scanner and catches exceptions*/
	static Scanner createFileScanner(File fileName, Scanner scannerName){
		//Create a scanner object for the file
		try{scannerName = new Scanner(fileName);}
		catch(Exception ex){System.out.print("Error with file input and/or output\n");}	
		return scannerName;
	}
	/** Method that creates a new file scanner and catches exceptions*/
	static FileWriter createFileWriter(File fileName, FileWriter outputFileName, Boolean bool){
		//Create a scanner object for the file
		try{outputFileName = new FileWriter(fileName, bool);}
		catch(Exception ex){System.out.print("Error with file input and/or output\n");}	
		return outputFileName;
	}
	
	//method that writes the contents of the game data object to the file
	void overwriteGameData(FileWriter outputFile){
		//for each element in the list
		for(int i = 0; i < players.size(); i++){
			//write the player name
			writeToFile(outputFile, players.get(i).name+"\n");
			//write the games string
			writeToFile(outputFile, players.get(i).games);
			//write the player divider 
			writeToFile(outputFile, playerDivider);
		}
	}
	
	/* ********************************************************************************************************************* *
	 *  Methods that interface with the game data and player objects *
	 * ******************************************************************************************************************* */
	
	//method that looks for the current user in the player list and tries to append the game to their record
	void updateUserRecord(String user, String game){
		int playerIndex = -1;
		//step through the list and find the index of the player object that has the matching name
		for(int i = 0; i < players.size(); i++){
			//if the player object at the index has the matching name set player index to the current index
			if(players.get(i).name.equals(user)){
				playerIndex = i;
			}
			//else do nothing
			else{;}
		}
		//if the user is in the list
		if(playerIndex >= 0){
			//simply call the appendGame method for that player object and pass the game string to it
			players.get(playerIndex).appendGame(game);
			}
		//if the user is not in the list
		else{	
			//create a new player object for them
			PlayerData player = new PlayerData(user);	
			//call the appendGameMethod for that player object and pass the game string to it
			player.appendGame(game);
			//add the new player to the list of players
			addPlayer(player);
		}
	}
	
	
	//method that reads in the current game data from the file
	void readData(File fileName){
		//create scanner 1
		Scanner inputFile1 = null;
		inputFile1 = createFileScanner(fileName, inputFile1);
		//create player counter
		int playerCount = 0;
		//while file has next
		while(inputFile1.hasNext()){	
			//if next line == player divider
			String line = inputFile1.nextLine();
			if(line.length() > 0 && line.charAt(0) == '*'){
				//increment player counter
				playerCount++;	
				}
			}
		//close scanner 1		
		inputFile1.close();

		
		//create scanner 2
		Scanner inputFile2 = null;
		inputFile2 = createFileScanner(fileName, inputFile2);
	//for each player in the file
		for(int i =0; i < playerCount; i ++){
			//if there is another line to read
			if(inputFile2.hasNext()){
				//get the name
				String name = inputFile2.nextLine();	
				//Create a new player object
				PlayerData player = new PlayerData(name);		
				//while the file has more lines to read
				while(inputFile2.hasNext()){	
					String line = inputFile2.nextLine();	
					//exit the loop when the player divider is reached
					if(line.charAt(0) == '*'){break;}
					else{
						//add the line to the string
						player.games += line +"\n";
					}
				}		
				//add the player to the list
				addPlayer(player);
			}
		}
	}
	
	//method that adds a player data object to the list
	private void addPlayer(PlayerData player){
		players.add(player);
	}
	
	/* ********************************** *
	 * End of main class *
	 * ********************************* */
	
	/* ********************************** *
	 * Begin nested class *
	 * ********************************* */
	
	/*nested class creates a player data object*/
	public class PlayerData {
		//string that holds the game data
		String games;	
		//string that holds the name
		String name;
		//no-arg constructor
		public PlayerData(){
		games = "";
		name = "???";
		}
	
		//constructor that accepts the user name
		public PlayerData(String n){
		games = "";
		name = n;
		}
		
		
		//method that appends a new game to the player's games string
		void appendGame(String game){
			games += game;
		}
	}

}
