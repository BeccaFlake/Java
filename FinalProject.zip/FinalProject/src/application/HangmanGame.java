/*
	 * Rebecca Flake and Levi Sprague
	 * 4/5/2018 through 4/30/2018
	 * Java
	 * Version 8
	 * Includes: 
	 * 		HangmanGui.java
	 * 		HangmanGame.java
	 * COP2552.001
	 * Final Project
	 *This class contains methods and data fields that run a game of hangman. 
 */

package application;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

class HangmanGame {
	//global variables and structures-RF
	final int ROUNDS;
	int gameCount;
	//Array list for the words -RF
	ArrayList<String> words = new ArrayList<String>(10);
	
	//integer variables -RF
	private int incorrectGuessCount,
		roundCount,
		winCount,
		lossCount,
		roundScoreCounter,
		totalScoreCounter;
	//string variables -RF
	private String name, 
			roundWord,
			hiddenWord,
			date;
	
	//series of parallel lists for keeping history previous games -LS
	//Modified to linked lists to integrate with the rest of the games file i/o
	private static LinkedList<String> historyNames = new LinkedList<String>();
	private static LinkedList<String> historyScores = new LinkedList<String>();
	private static LinkedList<String> historyDates = new LinkedList<String>();
	private static LinkedList<String> historyWins = new LinkedList<String>();
	private static LinkedList<String> historyLosses = new LinkedList<String>();
	

	/** no-arg constructor -RF*/
	HangmanGame(){
		//add the words to the arrayList -RF
		words.add("plum");
		words.add("apricot");
		words.add("quince");
		words.add("apple");
		words.add("tangerine");
		words.add("grape");
		words.add("necterine");
		words.add("persimmon");
		words.add("fig");
		words.add("dragonfruit");
		//set up the variables -RF
		ROUNDS = 10;
		name = "";
		roundWord = "";
		hiddenWord = "";
		roundCount = 0;
		winCount = 0;
		lossCount = 0;
		incorrectGuessCount = 0;
		roundScoreCounter = 0;
		totalScoreCounter = 0;
		gameCount = 0;
		//get the current date -RF
		Calendar calendar = new GregorianCalendar();					//a Gregorian calendar object which we will use to get the current date-RF
		int day  = calendar.get(Calendar.DATE);						//variable that will hold the current day of the month-RF
		int month = calendar.get(Calendar.MONTH) +1;					//variable that will hold the current month. because the parameter is 0 based, 1 is added to it-RF
		int year = calendar.get(Calendar.YEAR);						//variable that will hold the current year in yyyy format-RF
		date = (month + "/" + day + "/" + year);							//variable that will hold the date string in m[m]/d[d]/yyyy format	-RF
		shuffleWords();													//shuffle the words in the word bank upon creation -LS
	}
	
	/** Constructor that will accept the name as an argument -RF*/	
	HangmanGame(String n){
		//add the words to the arrayList -RF
		words.add("plum");
		words.add("apricot");
		words.add("quince");
		words.add("apple");
		words.add("tangerine");
		words.add("grape");
		words.add("necterine");
		words.add("persimmon");
		words.add("fig");
		words.add("dragonfruit");
		//set up the variables -RF
		ROUNDS = 10;
		name = n;
		roundWord = "";
		hiddenWord = "";
		roundCount= 0;
		winCount = 0;
		lossCount = 0;
		incorrectGuessCount = 0;
		roundScoreCounter = 0;
		totalScoreCounter = 0;
		gameCount = 0;
		//get the current date -RF
		Calendar calendar = new GregorianCalendar();						//a Gregorian calendar object which we will use to get the current date-RF
		int day  = calendar.get(Calendar.DATE);							//variable that will hold the current day of the month-RF
		int month = calendar.get(Calendar.MONTH) +1;						//variable that will hold the current month. because the parameter is 0 based, 1 is added to it-RF
		int year = calendar.get(Calendar.YEAR);							//variable that will hold the current year in yyyy format-RF
		date = (month + "/" + day + "/" + year);								//variable that will hold the date string in m[m]/d[d]/yyyy format	-RF
		shuffleWords();														//shuffle the words in the word bank upon creation -LS
	}
	
	/** Method that will validate the user's character input -RF*/
	static boolean getValidGuess(char guess){
		boolean validGuess = false;										//boolean variable that will indicate whether the name was valid-RF
		//the guess is valid if it is a character-RF
		if (Character.isLetter(guess)){
			//the control variable will be set to false-RF
			validGuess = true;
		}
		//the guess was not a letter-RF
		else{
			validGuess = false;
		}
		//check for white space characters-RF
		if(Character.isWhitespace(guess)){
			validGuess = false;
		}
		
		//return the valid name boolean -RF
		return validGuess;
	}
	
	/* **************************** *
	 * Setter Methods *
	 * ************************** */
	
	/** Method that sets the round count -RF */
	void setRoundCount(int count){
		roundCount = count;
	}
	/** Method that sets the win count -RF */
	void setWinCount(int count){
		winCount = count;
	}
	/** Method that sets the  loss count -RF */
	void setLossCount(int count){
		lossCount = count;
	}
	/** Method that sets the round word -RF */
	void setRoundWord(String word){
		roundWord = word;
	}
	/** Method that sets the incorrect guess count -RF */
	void setIncorrectGuessCount(int incorrectGuesses){
		incorrectGuessCount = incorrectGuesses;
	}
	/** Method that sets the total score counter -RF  */
	void setTotalScoreCounter(int totalScore){
		totalScoreCounter = totalScore;
	}
	/** Method that sets the round score counter -RF */
	void setRoundScoreCounter(int score){
		roundScoreCounter = score;
	}
	/** Method that sets the name -RF */
	void setName(String n){
		name = n; 
	}
	/* **************************** *
	 * Getter Methods *
	 * ************************** */
	
	/** Method that gets the round count -RF */
	int getRoundScoreCounter(){
		return roundScoreCounter;
	}
	/** Method that gets the incorrect guess count -RF */
	int getIncorrectGuessCount(){
		return incorrectGuessCount;
	}
	/** Method that gets the round count -RF */
	int getRoundCount(){
		return roundCount;
	}
	/** Method that sets the win count -RF */
	int getWinCount(){
		return winCount;
	}
	/** Method that sets the  loss count -RF */
	int getLossCount(){
		return lossCount;
	}
	/** Method that sets the  loss count -RF */
	int getTotalScoreCounter(){
		return totalScoreCounter;
	}
	int getGameCount(){
		return gameCount;
	}
	/** Method that sets the round word -RF */
	String getRoundWord(){
		return roundWord;
	}
	/** Method that gets the hidden word -RF */
	String getHiddenWord(){
		return hiddenWord;
	}
	/** Method that gets the name -RF */
	String getName(){
		return name;
	}
	/** Method that gets a historyName  -LS*/
	String getHistoryName(int index){
		return historyNames.get(index).toString();
	}
	
	/** Method that gets a historyScore  -LS*/
	String getHistoryScore(int index){
		return historyScores.get(index).toString();
	}
	
	/** Method that gets a historyWins  -LS*/
	String getHistoryWin(int index){
		return historyWins.get(index).toString();
	}
	
	/** Method that gets a historyLosses  -LS*/
	String getHistoryLoss(int index){
		return historyLosses.get(index).toString();
	}
	
	/** Method that gets a historyDate  -LS*/
	String getHistoryDate(int index){
		return historyDates.get(index).toString();
	}
	
	//shuffles the array of game words  -LS
	void shuffleWords(){
		Collections.shuffle(words);
	}
	
	
	/** Method that sets up the word for the round - RF*/
	void setHiddenWord(int currentRound){
		setRoundWord(words.get(currentRound));
		//make sure we are starting from an empty String -RF
		hiddenWord = "";
		//get the hiddenWordString -RF
		for(int i = 0; i < roundWord.length(); i++)
		{
			hiddenWord += "*";
		}
	}

	
	/** Method that updates the hidden word with the guessed letters -RF*/
	String changeHiddenWord(char guess){
		//convert the hidden word to a char array -RF
		char[] hiddenWordArray = hiddenWord.toCharArray();
		
		//step through the character array -RF
		for(int i = 0; i < hiddenWord.length(); i++){
			//if the guess is in the round word at the current index -RF
			if(guess == roundWord.charAt(i)){
				//replace the * at the index in the hidden word array with the guess -RF
				hiddenWordArray[i] = guess;
			}
			//otherwise -RF
			else{
				//do nothing -RF
				;
			}
		}
		//convert the hidden word array to a string -RF
		hiddenWord = String.valueOf(hiddenWordArray);
		//return the new hidden word string -RF
		return hiddenWord;
			
	}
	
	/** method that will check the user's input against the chosen word -RF*/
	Boolean checkGuess(char guess){
		boolean guessCheck = false;
		for(int i = 0; i < roundWord.length(); i++){
			if(guess == roundWord.charAt(i)){
				guessCheck = true;
			}
		}
		return guessCheck;
	}
	
	//load the saved data from the file  -LS
	void loadHistory(){
		
		try{
			FileReader reader = new FileReader("saveData");
			BufferedReader save = new BufferedReader(reader);
			
			//only the SAVE_GAME_COUNT most recent games will be read  -LS
			//Modified to linked lists to integrate into the file i/o for the rest of the games, as well as removing the limit on the number of games saved -RF
			for(int i = 0; i < historyNames.size(); i++){
				historyNames.add(save.readLine());
				historyDates.add(save.readLine());
				historyWins.add(save.readLine());
				historyLosses.add(save.readLine());
				historyScores.add(save.readLine());
				gameCount++;
			}
			save.close();
		}
		catch(Exception e){
			System.out.println("Something went wrong reading from the history file, a new file will be made at the end of the game.");
		}
		
		
	}
	
	//put the current play history at the front of each parallel array  -LS
	void updateHistory(GameData games){
		
		//Add the strings to the user record -RF
		games.updateUserRecord(name, date+"\n");
		games.updateUserRecord(name, Integer.toString(winCount)+"\n");
		games.updateUserRecord(name, Integer.toString(lossCount)+"\n");
		games.updateUserRecord(name, Integer.toString(totalScoreCounter)+"\n");
		games.updateUserRecord(name, GameData.gameDivider);
	}
	
	//save the history to the saveData file  -LS
	void saveHistory(GameData games){
		
		try{
			FileWriter writer = new FileWriter("saveData");
			
			//overwrite the game data  -RF
			games.overwriteGameData(writer);
			writer.close();
		}
		catch(Exception e){
			;
		}

	}
}
