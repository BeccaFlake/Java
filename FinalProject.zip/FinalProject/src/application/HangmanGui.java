/*
 * Rebecca Flake and Levi Sprague
 * 4/5/2018 through 4/30/2018
 * Java
 * Version 8
 * Includes: 
 * 		HangmanGui.java
 * 		HangmanGame.java
 * 		hangman0.png
 * 		hangman1.png
 * 		hangman2.png
 * 		hangman3.png
 * 		hangman4.png
 * 		hangman5.png
 * 		hangman6.png
 * COP2552.001
 * Final Project
 *This class handles a game of hangman that uses a graphical user interface. It utilizes the HangmanGame class to operate the game itself.
 */

package application;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

class HangmanGui{
	//Global variables and structures
	//image array -RF
	static Image[] images = {new Image("/hangman0.png"), new Image("/hangman1.png"), new Image("/hangman2.png"), new Image("/hangman3.png"), new Image("/hangman4.png"),
			new Image("/hangman5.png"), new Image("/hangman6.png")};
	static HangmanGame game;
	static Stage hangmanStage;
	static boolean popupInUse = false;
	static File saveData;
	static PrintWriter saveFile;
	
	//String for the username and a Game Data object for the games -RF
	static String name;
	static GameData games;
	
	/** Method that starts the game of hangman -RF*/
	static void startHangman(Stage primaryStage, String n){
		name = n;
		//make sure the save file exists - RF
		saveData = new File("saveData");
		try{
		//if file doesn't exist create a new one -RF
			if(!saveData.exists()){
				saveFile = new PrintWriter(saveData);
			}
		}
		catch(IOException ex){;}
		//call the menu scene method -LS
		hangmanStage = primaryStage;
		hangmanStage.show();
		showMenu();
		//create the game data object
		games = new GameData(saveData);	
		games.readData(saveData);
	}
	
/** Method that creates the menu */
	static void showMenu(){
		//the container for the hangman main menu -LS
		VBox hangmanMenu = new VBox(35);
		
		//the buttons and label for the hangman menu -LS
		Label hangmanLabel = new Label("Hangman");
		hangmanLabel.setFont(Font.font("Abyssinica SIL", 30));
		Button newGameButton = setButton("New Game");
			newGameButton.setPrefWidth(200);
			newGameButton.setPrefHeight(50);		
		Button historyButton = setButton("Game History"); 
			historyButton.setPrefWidth(200);
			historyButton.setPrefHeight(50);
		Button howToPlayButton = setButton("How to Play");
			howToPlayButton.setPrefWidth(200);
			howToPlayButton.setPrefHeight(50);
		Button returnButton = setButton("Return to Game\nSelection Menu");
	    	returnButton.setPrefWidth(200);
		    returnButton.setPrefHeight(50);
		Button exitButton = setButton("Exit");
			exitButton.setPrefWidth(200);
			exitButton.setPrefHeight(50);

		//allow the user to fire the buttons when they press enter and the the button has the focus -RF
		fireOnEnter(newGameButton);
		fireOnEnter(howToPlayButton);	
		fireOnEnter(historyButton);	
		fireOnEnter(returnButton);	
		fireOnEnter(exitButton);	
		//handers for the buttons -RF
		newGameButton.setOnAction(e -> startGame(name));
		historyButton.setOnAction(e -> showHistory());
		howToPlayButton.setOnAction(e -> showInstructions(false));
		returnButton.setOnAction(e-> Main.mainMenu());   //-RF
		exitButton.setOnAction(e -> System.exit(0));
		
		//adds each node the menu container -LS
		hangmanMenu.getChildren().add(hangmanLabel);
		hangmanMenu.getChildren().add(newGameButton);
		hangmanMenu.getChildren().add(historyButton);
		hangmanMenu.getChildren().add(howToPlayButton);
		hangmanMenu.getChildren().add(returnButton);
		hangmanMenu.getChildren().add(exitButton);
		hangmanMenu.setAlignment(Pos.CENTER);
		hangmanMenu.setStyle("-fx-background-color: #A1B8A1;");
		//display the scene and show the stage -LS
		Scene hangmanMenuScene = new Scene(hangmanMenu, 700, 600);
		
		hangmanStage.setTitle("Hangman");
		hangmanStage.setScene(hangmanMenuScene);
	}
	
/** Method that starts a new game */
	static void startGame(String username){
		//create the game object -RF
		game = new HangmanGame(username);
		//call the roundScene method -RF
		roundScene();
	}
	
	
/** Method that displays the rules of how to play  -LS */
	static void showInstructions(boolean popup_window){
		//do nothing if a popup is already in use -LS
		if(popupInUse)
			return;
		
		//the instructions for how to play hangman -LS
		String instructions = "How to Play Hangman:\n"
				+ "  •  Hangman is a game where you must guess the letters of a hidden word.\n\n"
				+ "  •  At first, the entire word will be hidden with a star * hiding each\n"
				+ "     letter of the word.\n\n"
				+ "  •  You begin by guessing letters from the alphabet. If the hidden word\n"
				+ "     contains the letter that you have guessed, all the hidden letters of\n"
				+ "     your guessed letter are revealed. For example, guessing 'n' and the\n"
				+ "     hidden word is banana, * * * * * * becomes -> * * n * n *\n\n"
				+ "  •  If an incorrect letter is guessed, the drawing of the hangman is\n"
				+ "     completed by a small amount.\n\n"
				+ "  •  The round ends when either you have guessed all letters in the\n"
				+ "     hidden word correctly, or the hangman image is complete.\n\n"
				+ "  •  You win by guessing all letters of the hidden word without\n"
				+ "     completing the hangman picture.\n\n"
				+ "  •  Points are awarded for winning based on the length of the word.";
		
		//the back button and label to contain the instructions -LS
		Button backButton = setButton("Back");
		Label instructionsLabel = new Label(instructions);
		//the container for the instructions scene elements -LS
		VBox instructionsContainer = new VBox(35);
		
		//add the instruction elements to its container -LS
		instructionsContainer.getChildren().add(instructionsLabel);
		instructionsContainer.getChildren().add(backButton);
		instructionsContainer.setAlignment(Pos.CENTER);
		instructionsContainer.setStyle("-fx-background-color: #A1B8A1;");		
		instructionsContainer.setPadding(new Insets(2, 0, 50, 0));
		//style the buttons and label -LS
		backButton.getStyleClass().add("menuButton");
		instructionsLabel.setFont(Font.font("Abyssinica SIL", 18));

		//reset the scene to the newly created instructions scene -LS
		Scene instructionsScene = new Scene(instructionsContainer, 700, 600);
		//allow the user to fire the button when they press enter and the the button has the focus -RF
		fireOnEnter(backButton);
		//if popup_window is true, show a popup window, otherwise change the hangman stage scene -LS
		if(popup_window == true){
			Stage popupStage = new Stage();
			popupStage.setTitle("Hangman - how to play");
			popupStage.show();
			popupStage.setScene(instructionsScene);
			popupStage.setAlwaysOnTop(true);
			popupInUse = true;
			backButton.setOnMouseClicked(e -> {popupStage.close(); popupInUse = false;	
			});
			//a handler for the window's exit button. We want to make sure the program closes gracefully -RF
			popupStage.setOnCloseRequest(windowEvent -> {
				//consume the event
				windowEvent.consume();
				popupStage.close(); popupInUse = false;
			});
		}
		else{
			hangmanStage.setTitle("Hangman - how to play");
			hangmanStage.setScene(instructionsScene);
			//add click functionality to the back button -LS
			backButton.setOnMouseClicked(e -> showMenu());
		}

	}
	
/** Method that displays the scores from the past games -LS */
	static void showHistory(){
		
		//create an instance of a hangman game to load previous history -LS
		HangmanGame pastGames = new HangmanGame();
		pastGames.loadHistory();
		
		Label namesLabel = new Label();
		Label datesLabel = new Label();
		Label winsLabel = new Label();
		Label lossesLabel = new Label();
		Label scoresLabel = new Label();
		Button backButton = setButton("Back");
		
		String namesText = "User Name:\n";
		String datesText = "Date Played:\n";
		String winsText = "Wins:\n";
		String lossesText = "Losses:\n";
		String scoresText = "Score:\n";
		
		HBox historyContainer = new HBox(30);
		
		//add the label and button to the container -LS
		historyContainer.getChildren().add(namesLabel);
		historyContainer.getChildren().add(datesLabel);
		historyContainer.getChildren().add(winsLabel);
		historyContainer.getChildren().add(lossesLabel);
		historyContainer.getChildren().add(scoresLabel);

		//style the buttons and labels -LS
		namesLabel.setFont(Font.font("Abyssinica SIL", 20));
		namesLabel.setTextAlignment(TextAlignment.CENTER);
		datesLabel.setFont(Font.font("Abyssinica SIL", 20));
		datesLabel.setTextAlignment(TextAlignment.CENTER);
		winsLabel.setFont(Font.font("Abyssinica SIL", 20));
		winsLabel.setTextAlignment(TextAlignment.CENTER);
		lossesLabel.setFont(Font.font("Abyssinica SIL", 20));
		lossesLabel.setTextAlignment(TextAlignment.CENTER);
		scoresLabel.setFont(Font.font("Abyssinica SIL", 20));
		scoresLabel.setTextAlignment(TextAlignment.CENTER);
		
		//create a scroll pane to hold the history container -RF
		ScrollPane scroll = new ScrollPane(historyContainer);
			scroll.setMaxWidth(550);
			scroll.setMaxHeight(420);
			scroll.setStyle("-fx-background: #A1B8A1; -fx-background-color: #A1B8A1;");
		
		//Add the hbox and the button to the vbox -RF
		VBox historyVbox = new VBox(50);
			historyVbox.getChildren().add(scroll);
			historyVbox.getChildren().add(backButton);
			historyVbox.setAlignment(Pos.CENTER);
		
		//style the container -LS
		historyContainer.setAlignment(Pos.CENTER);
		historyVbox.setStyle("-fx-background-color: #A1B8A1;");
		
		//allow the user to fire the button when they press enter and the the button has the focus -RF
		fireOnEnter(backButton);
		//add functionality to the back button -LS
		backButton.setOnMouseClicked(e -> showMenu());
		//Added a try catch block. it would crash if the file was empty or the file did not exist -RF
		try{
			
		//load the saved games into the historyText  -LS
			for(int i = 0; i < games.players.size(); i++){
				//get the name -RF
				namesText += games.players.get(i).name + "\n";
				//tokenize the games string  -RF
				String[] gamesArray = games.players.get(i).games.split(GameData.gameDivider);
				//for each game, split each line in to a string and place it in the corresponding text -RF
				for(int j = 0; j < gamesArray.length; j++){
					String[] linesArray = gamesArray[j].split("\n");
					if(j > 0){
						//add an empty line to the names to keep every thing even
						namesText += "-\n";
					}
					datesText += linesArray[0] + "\n"; 
					winsText += linesArray[1] + "\n" ;
					lossesText += linesArray[2] + "\n";
					scoresText +=linesArray[3] + "\n" ;
				}
				//add an empty line to make things more clear-RF
				namesText += "\n";
				datesText += "\n";
				winsText += "\n";
				lossesText += "\n";
				scoresText += "\n";
			}
		}
		//Catch the two exceptions it would throw when the file was empty or missing -RF
		catch(NullPointerException | IndexOutOfBoundsException ex){
			//there is no data to show. don't do anything -RF
			;
		}
		//set the text onto the corresponding labels -LS
		namesLabel.setText(namesText);
		datesLabel.setText(datesText);
		winsLabel.setText(winsText);
		lossesLabel.setText(lossesText);
		scoresLabel.setText(scoresText);

		
		Scene historyScene = new Scene(historyVbox, 700, 600);
		
		//set the new historyScene  -LS
		hangmanStage.setScene(historyScene);
		
	}
	
/** Method that starts the round -RF*/
	static void roundScene(){
		//set the word for the round up-RF
		game.setHiddenWord(game.getRoundCount());
		
		//Create the static UI elements -RF
			//text-RF
		Text wordTxt = new Text(game.getHiddenWord());
		//Let the user now what category the words are from -RF
		Text notificationTxt = new Text("Category is fruit");
		
		//text area-RF
		String guessedLettersS = "";
		TextArea guessedLettersTxt = new TextArea(guessedLettersS);
			guessedLettersTxt.setPrefColumnCount(10);
			guessedLettersTxt.setEditable(false);
		//text field-RF
		TextField guessField = new TextField();
		
		//image view-RF
		ImageView imageV = new ImageView(images[0]);
		imageV.setFitWidth(200);
		imageV.setFitHeight(200);
		//labels-RF
		Label roundsLbl = new Label("Rounds Played: " + (game.getRoundCount()));
		roundsLbl.setFont(Font.font("Abyssinica SIL", 16));
		Label winsLbl = new Label("Rounds Won: " +(game.getWinCount()) );
			winsLbl.setFont(Font.font("Abyssinica SIL", 16));;
		Label scoreLbl = new Label("Total Score: " + (game.getTotalScoreCounter()));
			scoreLbl.setFont(Font.font("Abyssinica SIL", 16));
		Label hiddenWordLbl = new Label("Your Word: ", wordTxt);
			hiddenWordLbl.setContentDisplay(ContentDisplay.RIGHT);
			hiddenWordLbl.setFont(Font.font("Abyssinica SIL", 16));
		Label guessLbl = new Label("Guess Here: ", guessField);
			guessLbl.setContentDisplay(ContentDisplay.RIGHT);
			guessLbl.setFont(Font.font("Abyssinica SIL", 16));
		Label guessedLbl = new Label("Guessed Letters", guessedLettersTxt);
			guessedLbl.setContentDisplay(ContentDisplay.BOTTOM);
			guessedLbl.setFont(Font.font("Abyssinica SIL", 16));
		Label guessesLeftLbl = new Label("Guesses Left: " + (6 - game.getIncorrectGuessCount()));
			guessesLeftLbl.setFont(Font.font("Abyssinica SIL", 16));
			
		//buttons-RF
		Button guessBtn = setButton("Guess");
		guessBtn.getStyleClass().add("menuButton");
		Button howToBtn = setButton("How to Play");
		Button backBtn = setButton("Back to Menu");
		backBtn.getStyleClass().add("menuButton");
		
		//Place the Ul elements in the pane-RF
			//hbox for the labels at the top-RF
		HBox labelsHbox = new HBox(20);
			labelsHbox.setAlignment(Pos.CENTER);	
			labelsHbox.getChildren().add(roundsLbl);
			labelsHbox.getChildren().add(winsLbl);
			labelsHbox.getChildren().add(scoreLbl);
		//vbox for the word and guess elements-RF
		VBox guessVbox = new VBox(15);
			guessVbox.getChildren().add(hiddenWordLbl);
			guessVbox.getChildren().add(guessLbl);
			guessVbox.getChildren().add(notificationTxt);
			guessVbox.getChildren().add(guessBtn);
			guessVbox.setAlignment(Pos.CENTER);
			
		//grid pane for the guessed letters, images, number of remaining guesses, and remaining button elements-RF
		GridPane roundGrid = new GridPane();
			roundGrid.setAlignment(Pos.CENTER);
			roundGrid.setPadding(new Insets(15, 10, 15, 10));
			roundGrid.setHgap(80);
			roundGrid.setVgap(20);
			roundGrid.add(guessedLbl, 0, 0);
			roundGrid.add(imageV, 1, 0);
			roundGrid.add(guessesLeftLbl, 1, 1);
			roundGrid.add(howToBtn, 0, 2);
			roundGrid.add(backBtn, 1, 2);
			GridPane.setHalignment(guessedLbl, HPos.CENTER);
			GridPane.setHalignment(imageV, HPos.CENTER);
			GridPane.setHalignment(guessesLeftLbl, HPos.CENTER);
			GridPane.setHalignment(howToBtn, HPos.CENTER);
			GridPane.setHalignment(backBtn, HPos.CENTER);
		//VBox for the main nodes -RF
		VBox roundVbox = new VBox(25);
			roundVbox.setAlignment(Pos.CENTER);
			roundVbox.getChildren().add(labelsHbox);
			roundVbox.getChildren().add(guessVbox);
			roundVbox.getChildren().add(roundGrid);
			roundVbox.setStyle("-fx-background-color: #A1B8A1;");
		//place the pane in the scene-RF
		Scene roundScene = new Scene(roundVbox, 700, 600);
		
		//display the scene-RF
		hangmanStage.setScene(roundScene);
		hangmanStage.show();
		
		//event handler that clears the text field when it is clicked-RF
		guessField.setOnAction(e -> guessField.setText(""));
		
		//allow the user to fire the button when they press enter and the the button has the focus -RF
		fireOnEnter(guessBtn);
		fireOnEnter(howToBtn);
		fireOnEnter(backBtn);
	//event handlers for the buttons -RF
		//set the guess button to fire when enter is pressed in the guessField  -LS
		guessField.setOnAction(e -> guessBtn.fire());
		//handler for the guess button that checks the input and then calls the check guess method-RF
		guessBtn.setOnAction(e -> {
			String s= " ";
			char guess = ' ';
			//gather the input from the field-RF
			try{
				s = guessField.getText();
				s = s.toLowerCase();
				guess = s.charAt(0);
			}
			catch(IndexOutOfBoundsException ex){
				notificationTxt.setText("Please enter a letter");
			}
			
			//Make sure the input wasn't white space -RF
			if(Character.isWhitespace(guess)){
				notificationTxt.setText("Enter your guess.");
			}
			//make sure the letter has already been guessed -RF
			else if(guessedLettersTxt.getText().contains(s)){
				notificationTxt.setText("That letter was already guessed.");
				//increment the incorrect guess counter-RF
				game.setIncorrectGuessCount((game.getIncorrectGuessCount() + 1));
				//change the picture
				imageV.setImage(images[game.getIncorrectGuessCount()]);
				//change the number of incorrect guesses left label-RF
				guessesLeftLbl.setText("Incorrect Guesses Left: " + (6 - game.getIncorrectGuessCount()));
			}
			//if the valid input method returns true and it is not already in the text area's string-RF
			else if(HangmanGame.getValidGuess(guess)){
				//add it to the guessed letters textarea-RF
					//if the line is getting too long for the area start a new line -RF
					if(guessedLettersTxt.getText().length() == 15){
						guessedLettersTxt.setText(guessedLettersTxt.getText() + guess + "\n");
					}
					//otherwise just add the guess to the area-RF
					else{
						guessedLettersTxt.setText(guessedLettersTxt.getText() + guess + " ");
					}
				
					
					//if the check guess method returns true-RF
					if(game.checkGuess(guess)){
						//call the update hidden word method, which will return a string-RF
						//update the hiddenword label-RF
						wordTxt.setText(game.changeHiddenWord(guess));
						//let the user know their guess was correct-RF
						notificationTxt.setText("Great job!");
					}
					else{
						//increment the incorrect guess counter-RF
						game.setIncorrectGuessCount((game.getIncorrectGuessCount() + 1));
						//change the picture -RF
						imageV.setImage(images[game.getIncorrectGuessCount()]);
						//change the number of incorrect guesses left label-RF
						guessesLeftLbl.setText("Incorrect Guesses Left: " + (6 - game.getIncorrectGuessCount()));
						//let the user know the letter isn't in the word-RF
						notificationTxt.setText("That letter isn't in the word");
					}
				}
				//else the valid input method returns false-RF
				else{
					//update the string in the guess notificationTxt to notify the user that it isn't a valid input and they need to try again-RF
					notificationTxt.setText("Please enter a letter");
				}
				//clear the text field -RF
				guessField.setText("");	
				//when the hidden word no longer contains and *'s or the user runs out of incorrect guesses -RF
				if( (!game.getHiddenWord().contains("*")) || (game.getIncorrectGuessCount() == 6)){
					//increment the round counter -RF
					game.setRoundCount(game.getRoundCount() + 1);
				//add to the win counter or the loss counter-RF
					if(!game.getHiddenWord().contains("*")){
						game.setWinCount((game.getWinCount() + 1));
						//set the score -RF
						game.setRoundScoreCounter(((game.getRoundWord().length() *5) -2));
						//add the round score to the total score-RF
						game.setTotalScoreCounter((game.getRoundScoreCounter() + game.getTotalScoreCounter()));
					}
					if(game.getIncorrectGuessCount() == 6){
						game.setLossCount(game.getLossCount() + 1);
					}
					//generate a pop up asking if they would like to play again-RF
					playAgain();
				}
			});
		
		howToBtn.setOnMouseClicked(e -> showInstructions(true));
		//handler for the back button. calls the quit method to gracefully return the user to the menu-RF
		backBtn.setOnAction(e -> backToMenu());
		//exit handler for the window's exit button -RF
		hangmanStage.setOnCloseRequest(windowEvent -> {
			//consume the event -RF
			windowEvent.consume();
			//then call exit to close the program gracefully if the user is sure -RF
			exit();
		});
	}
	
	
/** Method that creates the play again popup-RF*/
	static void playAgain(){
		//create UI elements -RF
		//Text objects -RF
		Text endOfRoundTxt = new Text("The word was " + game.getRoundWord() + ". You got " + game.getRoundScoreCounter() + " points.");
		if(game.getRoundCount() >= 10){
			endOfRoundTxt.setText(endOfRoundTxt.getText() + " You played through all of the words! If you play again the order will be reshuffled.");
		}
		endOfRoundTxt.setTextAlignment(TextAlignment.CENTER);
		//buttons -RF
		Button yesBt = setButton("Yes");
		Button noBt = setButton("No");
		//put the buttons into a vbox -RF
		VBox buttonVbox = new VBox(20);
			buttonVbox.getChildren().add(yesBt);
			buttonVbox.getChildren().add(noBt);
			buttonVbox.setPadding(new Insets(15, 10, 15 , 10));
			buttonVbox.setSpacing(20);
			buttonVbox.setAlignment(Pos.CENTER);
		
		//label for the buttons -RF
		Label playAgainLbl = new Label("Play Again?", buttonVbox);
			playAgainLbl.setContentDisplay(ContentDisplay.BOTTOM);
			
		//Vbox for the contents -RF
		VBox playAgainVbox = new VBox(20);	
			playAgainVbox.getChildren().add(endOfRoundTxt);
			playAgainVbox.getChildren().add(playAgainLbl);
			playAgainVbox.setPadding(new Insets(15, 10, 15 , 10));
			playAgainVbox.setAlignment(Pos.CENTER);
			playAgainVbox.setStyle("-fx-background-color: #A1B8A1;");
		//create the stage -RF
		Stage stage = new Stage();
		stage.setScene(new Scene(playAgainVbox, 300, 200));
		stage.setTitle("Hangman - play again");
		stage.show();
		
		//allow the user to fire the button when they press enter and the the button has the focus -RF
		fireOnEnter(yesBt);
		fireOnEnter(noBt);
		//set escape for no  -LS/RF
		buttonVbox.setOnKeyPressed(e -> {
			if(e.getCode().equals(KeyCode.ESCAPE))
				noBt.fire();
		});
		
		//Yes button handler  -RF
		yesBt.setOnAction( e -> {
			//if the user has played through all of the words let them know and then shuffle the words in the array reset the variables as needed and then call the round again -RF
			if(game.getRoundCount() >= 10){
				game.updateHistory(games);
				game.saveHistory(games);
				game.shuffleWords();
				game.setIncorrectGuessCount(0);
				game.setRoundScoreCounter(0);
				game.setRoundCount(0);
				game.setLossCount(0);
				game.setWinCount(0);
				game.setTotalScoreCounter(0);
				roundScene();
				stage.close();
			}	
					
			//if the user has not played through all the words just reset the variables as needed and then call the round again -RF
			else{
				game.setRoundScoreCounter(0);
				game.setIncorrectGuessCount(0);
				roundScene();
				stage.close();
			}
		});
		
		//if no, exit to the menu -RF
		noBt.setOnAction(e -> {showMenu(); stage.close(); game.updateHistory(games); game.saveHistory(games);});
		//a handler for the window's exit button. We want to make sure the program closes gracefully -RF
		stage.setOnCloseRequest(windowEvent -> {
			//consume the event
			windowEvent.consume();
			stage.close(); popupInUse = false;
		});
	}
	
	
	/* Methods that handle quitting the game -RF */
	
	
	/** Method that returns the user to the main menu -RF.*/
	static void backToMenu(){
		//do nothing if a popup is already in use -LS
		if(popupInUse)
			return;
		//create the UI elements
		Text txt = new Text("Are you sure?");				
			txt.setStyle("-fx-text-align: center;"); 
			txt.setFont(Font.font("Abyssinica SIL", 16));
		//Create the buttons -RF
		Button yesBt =  setButton("Yes");
			yesBt.setMinWidth(50);
		Button noBt = setButton("No");
			noBt.setMinWidth(50);
		
		//hbox for the buttons -RF
		HBox hBox= new HBox(20);
			hBox.getChildren().add(yesBt);
			hBox.getChildren().add(noBt);
			hBox.setAlignment(Pos.CENTER);
		//vbox for the text and buttons -RF
		VBox vBox= new VBox(35);
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);
			vBox.setAlignment(Pos.CENTER);
		
		//Create a border pane -RF
		BorderPane exitPane = new BorderPane();
			exitPane.setCenter(vBox);
			exitPane.setStyle("-fx-background-color: #A1B8A1;");
		//create the new scene -RF
		Scene scene = new Scene(exitPane, 200, 150);
		Stage stage = new Stage();
		stage.setTitle("Hangman - back to menu");
		stage.setAlwaysOnTop(true);
		popupInUse = true;
		stage.setScene(scene);
		//Display the Stage -RF
		stage.show();
		
		//allow the user to fire the button when they press enter and the the button has the focus -RF
		fireOnEnter(yesBt);
		fireOnEnter(noBt);
		
		//set escape for no  -LS/RF
		exitPane.setOnKeyPressed(e -> {
			if(e.getCode().equals(KeyCode.ESCAPE))
				noBt.fire();
		});
		
		//Event handlers -RF
		yesBt.setOnAction(e -> {
				showMenu();
				stage.close();
				popupInUse = false;
				//save the user's current session and save the saveData file  -LS
				game.updateHistory(games);
				game.saveHistory(games);
				
			});
		//the answer was no, close the new stage -LS
		noBt.setOnAction(e -> {stage.close(); popupInUse = false;});
		//a handler for the window's exit button. We want to make sure the program closes gracefully -RF
		stage.setOnCloseRequest(windowEvent -> {
			//consume the event
			windowEvent.consume();
			stage.close(); popupInUse = false;
		});
	}	
	
	/** Method that exits the game completely -RF */
	static void exit(){
		//do nothing if a popup is already in use -LS
		if(popupInUse)
			return;
		
	//create the UI elements
		Text txt = new Text("Are you sure you\nwant to exit?");					
			txt.setStyle("-fx-text-align: center;"); 
			txt.setFont(Font.font("Abyssinica SIL", 16));
		//Create the buttons -RF
		Button yesBt =  setButton("Yes");
			yesBt.setMinWidth(50);
		Button noBt = setButton("No");
			noBt.setMinWidth(50);
		
		//hbox for the buttons -RF
		HBox hBox= new HBox(20);
			hBox.getChildren().add(yesBt);
			hBox.getChildren().add(noBt);
			hBox.setAlignment(Pos.CENTER);
		//vbox for the text and buttons -RF
		VBox vBox= new VBox(35);
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);
			vBox.setAlignment(Pos.CENTER);
		
		//Create a border pane -RF
		BorderPane exitPane = new BorderPane();
			exitPane.setCenter(vBox);
			exitPane.setStyle("-fx-background-color: #A1B8A1;");
		//create the new scene -RF
		Scene scene = new Scene(exitPane, 200, 150);
		Stage stage = new Stage();
		stage.setTitle("Hangman - quit");
		stage.setScene(scene);
		stage.setAlwaysOnTop(true);
		popupInUse = true;
		//Display the Stage -RF
		stage.show();
		
		//allow the user to fire the button when they press enter and the the button has the focus -RF
		fireOnEnter(yesBt);
		fireOnEnter(noBt);
		
		//set escape for no  -LS/RF
		exitPane.setOnKeyPressed(e -> {
			if(e.getCode().equals(KeyCode.ESCAPE))
				noBt.fire();
		});
		//Event handlers -RF
		yesBt.setOnAction(e -> {

				//save the user's current session then save the saveData  -LS
				game.updateHistory(games);
				game.saveHistory(games);
				stage.close();		
			//Exit the game
			Platform.exit();
			});
		//the answer was no, close the new stage  -LS
		noBt.setOnAction(e -> {stage.close(); popupInUse = false;});
		//exit handler for the window's exit button -RF
		stage.setOnCloseRequest(windowEvent -> {
			//consume the event
			windowEvent.consume();
			stage.close(); popupInUse = false;
		});
	}
	
	/** Method that sets up the appearance of the button -RF*/
	static Button setButton(String s){
		Button b = new Button(s);
		b.setFont(Font.font("Abyssinica SIL", 16));
		b.setStyle("-fx-background-color: #468844; -fx-border-color: #468844; -fx-text-fill: #F1F1F1;"
				+ "-fx-border-radius: 15,15,15,15;");
		b.setMinWidth(100);
		b.setPrefHeight(25);
		b.setFocusTraversable(true);
		//set drop shadow
		 DropShadow dropShadow = new DropShadow();
			 dropShadow.setRadius(4.0);
			 dropShadow.setOffsetX(2.0);
			 dropShadow.setOffsetY(2.0);
			 dropShadow.setColor(Color.color(0.026, 0.108, 0.120)); 
			 b.setEffect(dropShadow);
		return b;
	}
	
	/** method that handles firing the buttons when enter is pressed -RF*/
	static void fireOnEnter(Button b){
		b.setOnKeyPressed(e -> {
			if(e.getCode().equals(KeyCode.ENTER) && b.isFocused())
				b.fire();
		});
	}
}
