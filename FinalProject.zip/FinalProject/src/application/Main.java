/*
Rebecca Flake
4-1-2018 Through 4-30-2018 
Java
Version 8
Includes: 
   Java-
	File, FileWriter, and IOException classes
	Scanner class
   JavaFx-
	Application and Platform classes
	ActionEvent and EventHandler classes
	HPos, Insets, and Pos classes
	Stage class
	Duration Class
	Button, CheckBox, ContentDisplay, Label, TextArea, and TextField classes
	Drop shadow class
	Image and ImageView classes
	BorderPane, GridPane, HBox, StackPane, and VBox classes
	Media and MediaPlayer classes
	Color class
	Rectangle class
	Font and Text classes
   Files
   	username.txt
COP2552.001
Final Project
This class allows the user to sign in with a new or existing user name. The user can then choose from 3 games (yahtzee, hangman, and blackjack) to play. 
This program maintains a file of user names. All of the score data for each game is handled by the game itself. 
 */


package application;
	

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;


public class Main extends Application {
	//Stage Object for the main stage of the program
	static Stage mainStage;
	//String variable for the username 
	static String username;
	
	//Create the static file reference variables
	static File userNameFile;		
	static Scanner userNameFileIn;
	static FileWriter userNameFileOut;


	
	
	@Override
	public void start(Stage primaryStage) {
		//set the main stage to the primary stage
		mainStage = primaryStage;
		try {
			//create the file objects
			userNameFile = new File("username.txt");	
			
			//create a new file if none exists
			if (!userNameFile.exists()){
				userNameFileOut = new FileWriter(userNameFile);
			}			
			
			//Set the title of the primary stage
			mainStage.setTitle("Play Games");
			//set the starting sizes for the stage
			mainStage.setWidth(1200);
			mainStage.setHeight(700);
			//set the minimum sizes for the stage
			mainStage.setMinWidth(1200);
			mainStage.setMinHeight(700);
			//Get  the first scene
			welcomeScene();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**Method that creates the very first scene */
	static void welcomeScene(){
	//set up UI Elements
		//Text	
		//create a text object that will serve as the title
		Text titleTxt = new Text("Welcome");
			titleTxt.setFont(Font.font("Abyssinica SIL", 50));
			titleTxt.setFill(Color.color(.255, .255, .255));
		//Button
		Button newUserBtn  = setButton("New user");
		Button returnUserBtn = setButton("Returning User");

		//hbox for the buttons
		HBox btnHbox = new HBox(30);
			btnHbox.setAlignment(Pos.CENTER);
			btnHbox.getChildren().add(newUserBtn);
			btnHbox.getChildren().add(returnUserBtn);
		
		//vBox for the scene
		VBox sceneVbox = new VBox(200);
			sceneVbox.setPadding(new Insets(100,5,5,5));
			sceneVbox.getChildren().add(titleTxt);
			sceneVbox.getChildren().add(btnHbox);
			sceneVbox.setAlignment(Pos.TOP_CENTER);
			sceneVbox.setStyle("-fx-background-color: #B5B5B5;");

		/*Create a scene and place the plane into it and set it as the primary stage's scene.
		The height and width are set to what ever the current size of the primary stage - this seems to then apply to all scenes until it is overridden*/
		Scene welcomeScene = new Scene(sceneVbox, mainStage.getWidth(), mainStage.getHeight());
		mainStage.setScene(welcomeScene);
			
		//Display the Stage
		mainStage.show();
	
		//Listeners for the stage size so that the scene can be resized
		mainStage.widthProperty().addListener(ov -> {sceneVbox.setPrefWidth(mainStage.getWidth());});
		mainStage.heightProperty().addListener(ov-> {sceneVbox.setPrefHeight(mainStage.getHeight());});
		
		//event handlers for the buttons
		newUserBtn.setOnAction(e-> newUserMainScene());
		returnUserBtn.setOnAction(e -> returningUserMainScene());
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(returnUserBtn);
		fireOnEnter(newUserBtn);
	}

	
	/** Method that creates the new user main scene */ 
	static void newUserMainScene(){
	//set up UI Elements
		//Text	
		//create a text object that will be used as the title on each scene. This reduces redundancy.
		Text titleTxt = new Text("Welcome");
			titleTxt.setFont(Font.font("Abyssinica SIL", 50));
			titleTxt.setFill(Color.color(.255, .255, .255));
		Text instructTxt = new Text("Please enter the username you would like to use.\nAll of your game data will be attached to this name.\n"
				+ "The name should be 3-10 characters long and easy for you to remember.\nIt cannot include the characters '*' or '-' and will be case sensitive.");
			instructTxt.setFont(Font.font("Abyssinica SIL", 20));
			instructTxt.setTextAlignment(TextAlignment.CENTER);
			instructTxt.setFill(Color.color(.255, .255, .255));
		//TextField
		TextField usernameTF = new TextField();   //text field object for the username entry									 		
			usernameTF.setPrefColumnCount(25);
			usernameTF.setMaxWidth(200);
			usernameTF.setStyle("-fx-background-color: #F1F1F1; ");
			usernameTF.setFont(Font.font("Abyssinica SIL", 16));
			usernameTF.setEditable(true);
			usernameTF.setFocusTraversable(true);
		
		//Button
		Button createUserNameBtn  = setButton("Create Username");
		Button backBt = setButton("Back");
		//vBox for the scene
		VBox sceneVbox = new VBox(50);
			sceneVbox.setPadding(new Insets(100,5,5,5));
			sceneVbox.getChildren().add(titleTxt);
			sceneVbox.getChildren().add(instructTxt);
			sceneVbox.getChildren().add(usernameTF);
			sceneVbox.getChildren().add(createUserNameBtn);
			sceneVbox.getChildren().add(backBt);
			sceneVbox.setAlignment(Pos.TOP_CENTER);
				sceneVbox.setStyle("-fx-background-color: #B5B5B5;");

		/*Create a scene and place the plane into it, set it as the primary stage's scene
		the height and width are set to what ever the current size of the primary stage - this seems to then apply to all scenes until it is overridden*/
		Scene welcomeScene = new Scene(sceneVbox, mainStage.getWidth(), mainStage.getHeight());
		mainStage.setScene(welcomeScene);
			
		//Display the Stage
		mainStage.show();
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(createUserNameBtn);
		fireOnEnter(backBt);
		
		backBt.setOnAction(e -> welcomeScene());
		//event handler for the button
		createUserNameBtn.setOnAction(e -> {
			//search the username file for the user name
				//if the username already exists
				if(searchUserNameFile(usernameTF.getText())){
					//call the username not unique method
					instructTxt.setText("Sorry, that name is already in use. Could you try a different username?\n"
							+ "It should be 3-10 characters long and easy to remember.\nIt cannot include the characters '*' or '-' and will be case sensitive.");
				}
				//else if the username is out of the length range let the user know and clear the input
				else if(usernameTF.getText().length() < 3){
					usernameTF.setText("Sorry that's too short");
				}
				//else if the username is out of the length range let the user know and clear the input
				else if(usernameTF.getText().length() > 10){
					usernameTF.setText("Sorry that's too long");
				}
				//else if the username contains a forbidden character
				else if(usernameTF.getText().contains("*") || usernameTF.getText().contains("-")){
					usernameTF.setText("Character not allowed.");
				}
				//else append the user name to the file and then call the proceedToMenuScene method with the argument true
				else{
					try{
						userNameFileOut = new FileWriter(userNameFile, true);
						userNameFileOut.append(usernameTF.getText() + "\n");
						userNameFileOut.close();
					}
					catch(IOException ex){System.out.println("There was an error writing the user name to the file");}
					
					proceedToMenuScene(true, usernameTF.getText());
				}
		});	
	}
	
	/** Method that creates the new user main scene */ 
	static void returningUserMainScene(){
	//set up UI Elements
		//Text	
		//create a text object that will be used as the title on each scene. This reduces redundancy.
		Text titleTxt = new Text("Welcome Back");
			titleTxt.setFont(Font.font("Abyssinica SIL", 50));
			titleTxt.setFill(Color.color(.255, .255, .255));
		Text instructTxt = new Text("Please enter your username to sign in.\nRemember that it is case sensative\n");
			instructTxt.setFont(Font.font("Abyssinica SIL", 20));
			instructTxt.setTextAlignment(TextAlignment.CENTER);
			instructTxt.setFill(Color.color(.255, .255, .255));
		//TextField
		TextField usernameTF = new TextField();   //text field object for the user name entry									 		
			usernameTF.setPrefColumnCount(25);
			usernameTF.setMaxWidth(200);
			usernameTF.setStyle("-fx-background-color: #F1F1F1; ");
			usernameTF.setFont(Font.font("Abyssinica SIL", 16));
			usernameTF.setEditable(true);
			usernameTF.setFocusTraversable(true);
		
		//Button
		Button loginBt  = setButton("Log in");
		Button newUserNameBt = setButton("Go Create New User Name");
		Button backBt = setButton("Back");
			newUserNameBt.setOpacity(0);
		//vBox for the scene
		VBox sceneVbox = new VBox(20);
			sceneVbox.setPadding(new Insets(100,5,5,5));
			sceneVbox.getChildren().add(titleTxt);
			sceneVbox.getChildren().add(instructTxt);
			sceneVbox.getChildren().add(usernameTF);
			sceneVbox.getChildren().add(loginBt);
			sceneVbox.getChildren().add(newUserNameBt);
			sceneVbox.getChildren().add(backBt);
			sceneVbox.setAlignment(Pos.TOP_CENTER);
			sceneVbox.setStyle("-fx-background-color: #B5B5B5;");
		/*Create a scene and place the plane into it, set it as the primary stage's scene
		the height and width are set to what ever the current size of the primary stage - this seems to then apply to all scenes until it is overridden*/
		Scene welcomeScene = new Scene(sceneVbox, mainStage.getWidth(), mainStage.getHeight());
		mainStage.setScene(welcomeScene);
			
		//Display the Stage
		mainStage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(loginBt);
		fireOnEnter(newUserNameBt);
		fireOnEnter(backBt);
		
		backBt.setOnAction(e -> welcomeScene());
		//event handler for the button
		loginBt.setOnAction(e -> {
			//search the username file for the user name
				//if the username already exists than proceed 
				if(searchUserNameFile(usernameTF.getText())){
					//call the method and pass the boolean false, as it is a returning user
					proceedToMenuScene(false, usernameTF.getText());
					//call the username not unique method
	
				}
				else if(usernameTF.getText().length() == 0 ){
					instructTxt.setText("Please enter a username");
					loginBt.setText("Try Again");
				}
				//else append the user name to the file and then call the proceedToMenuScene method with the argument true
				else{
					instructTxt.setText("That username doesn't seem to exist.\nYou can try to enter it again or you can make a new username."
							+ "\nUsernames are case sensative");
					loginBt.setText("Try Again");
					//reveal the new username button.
					newUserNameBt.setOpacity(1);
					newUserNameBt.setOnAction(ActionEvent -> newUserMainScene());
				}
		
		});
	}
	
	/**Method that creates the scene that allows the user to proceed to the menu*/
	static void proceedToMenuScene(Boolean newUser, String uname){
		//string variable to hold the greeting
		String message =" ";
		//set the global user name variable to the one given as an argument
		username = uname;
		
		//set up UI Elements
		//Text	
		Text titleTxt = new Text("Login Successful");
			titleTxt.setFont(Font.font("Abyssinica SIL", 50));
			titleTxt.setFill(Color.color(.255, .255, .255));
		//if it is a new user
		if(newUser){
			message = "Welcome " + username + "!"
					+ "\nA new username has been created for you."
					+ "\nYour game data will be linked to this name, so make sure you sign in with it next time.";
		}
		//it is a returning user
		else{
			message = "Welcome back " + username + "!";
		}
		
		Text instructTxt = new Text(message);
			instructTxt.setFont(Font.font("Abyssinica SIL", 20));
			instructTxt.setTextAlignment(TextAlignment.CENTER);
			instructTxt.setFill(Color.color(.255, .255, .255));
		
		//Button
		Button continueBt  = setButton("Continue to Main Menu");
		
		//vBox for the scene
		VBox sceneVbox = new VBox(50);
			sceneVbox.setPadding(new Insets(100,5,5,5));
			sceneVbox.getChildren().add(titleTxt);
			sceneVbox.getChildren().add(instructTxt);
			sceneVbox.getChildren().add(continueBt);
			sceneVbox.setAlignment(Pos.TOP_CENTER);
			sceneVbox.setStyle("-fx-background-color: #B5B5B5;");
		/*Create a scene and place the plane into it, set it as the primary stage's scene
		the height and width are set to what ever the current size of the primary stage - this seems to then apply to all scenes until it is overridden*/
		Scene welcomeScene = new Scene(sceneVbox, mainStage.getWidth(), mainStage.getHeight());
		mainStage.setScene(welcomeScene);
			
		//Display the Stage
		mainStage.show();

		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(continueBt);
		//handler for the continue button
		continueBt.setOnAction(e-> mainMenu());
	}
	
	/** Method that creates the main menu */
	static void mainMenu(){
		//set up UI Elements
		//Text	
		Text titleTxt = new Text("Which game would you like to play?");
			titleTxt.setFont(Font.font("Abyssinica SIL", 50));
			titleTxt.setFill(Color.color(.255, .255, .255));
		
		//Button
		Button yahtzeeBt  = setButton("Yahtzee");
			yahtzeeBt.setStyle("-fx-background-color: #377894; -fx-border-color: #377894;  -fx-text-fill: #F1F1F1; -fx-border-radius: 15,15,15,15;");
		Button hangmanBt  = setButton("Hangman");
			hangmanBt.setStyle("-fx-background-color: #468844; -fx-border-color: #468844;  -fx-text-fill: #F1F1F1; -fx-border-radius: 15,15,15,15;");
		Button blackjackBt  = setButton("Blackjack");
			blackjackBt.setStyle("-fx-background-color: #AD6C82; -fx-border-color: #AD6C82; -fx-text-fill: #F1F1F1; -fx-border-radius: 15,15,15,15;");
		Button backBt = setButton("Back to Login");
		Button exitBt  = setButton("Exit");
	
		//vBox for the scene
		VBox sceneVbox = new VBox(30);
			sceneVbox.setPadding(new Insets(100,5,5,5));
			sceneVbox.getChildren().add(titleTxt);
			sceneVbox.getChildren().add(yahtzeeBt);
			sceneVbox.getChildren().add(hangmanBt);
			sceneVbox.getChildren().add(blackjackBt);
			sceneVbox.getChildren().add(backBt);
			sceneVbox.getChildren().add(exitBt);
			sceneVbox.setAlignment(Pos.TOP_CENTER);
			sceneVbox.setStyle("-fx-background-color: #B5B5B5;");
		/*Create a scene and place the plane into it, set it as the primary stage's scene
		the height and width are set to what ever the current size of the primary stage - this seems to then apply to all scenes until it is overridden*/
		Scene welcomeScene = new Scene(sceneVbox, mainStage.getWidth(), mainStage.getHeight());
		mainStage.setScene(welcomeScene);
			
		//Display the Stage
		mainStage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(yahtzeeBt);
		fireOnEnter(hangmanBt);
		fireOnEnter(blackjackBt);
		fireOnEnter(backBt);
		fireOnEnter(exitBt);
		//handlers for the buttons
		yahtzeeBt.setOnAction(e-> YahtzeeGUI.startYahtzee(mainStage, username));
		hangmanBt.setOnAction(e-> HangmanGui.startHangman(mainStage, username));
		blackjackBt.setOnAction(e-> BlackJackGUI.startBlackjack(mainStage, username) );
		backBt.setOnAction(e -> welcomeScene());
		exitBt.setOnAction(e-> exit());
	}
	
	
	/** Method that exits the application completely*/
	static void exit(){
	//create the UI elements
		//Text
		Text txt = new Text("Are you sure?");			//text object for the question
			txt.setTextAlignment(TextAlignment.CENTER);
			txt.setFont(Font.font("Abyssinica SIL", 16));
		//Button
		Button yesBt = setButton("Yes");					
		Button noBt = setButton("No");

		//hbox for the buttons
		HBox hBox= new HBox(20);
			hBox.setAlignment(Pos.CENTER);	
			hBox.getChildren().add(yesBt);
			hBox.getChildren().add(noBt);
		//vbox for the text and the buttons
		VBox vBox= new VBox(35);
			vBox.setAlignment(Pos.CENTER);		
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);

		//Create a border pane
		BorderPane exitPane = new BorderPane();
			exitPane.setStyle("-fx-background-color: #B5B5B5;");
			exitPane.setCenter(vBox);
		//create the new scene
		Scene scene = new Scene(exitPane, 350, 250);		
		Stage stage = new Stage();
		stage.setTitle("Exit");
		stage.setScene(scene);
		//Display the Stage
		stage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(yesBt);
		fireOnEnter(noBt);
		
		//Event handlers
		yesBt.setOnAction(e -> {
			//make sure the files are closed
			try{
				//file 1
				userNameFileIn.close();
				//file 2
				userNameFileOut.close();
			}
			catch(Exception ex){
				System.out.print("no files were open");
			}
			//close the application
			Platform.exit();
		});
		//if the answer is no, close the new stage
		noBt.setOnAction(e -> stage.close());
	}
	
	
	/** Method that looks in the user name file for the entered username */
	static Boolean searchUserNameFile(String username){
		Boolean match = false;
		//create the file scanner
		try{
			userNameFileIn = new Scanner(userNameFile);
			//while the end of the file has not been reached
			while(userNameFileIn.hasNext()){
				//see if the input matches the string
				String fileIn = userNameFileIn.nextLine();
				//if it matches
				if(username.equals(fileIn)){
					//return true
					match = true;
				}
				//else don't do anything, the boolean is false by default
				else{;}
			}
			//close the file
			userNameFileIn.close();
		}
		catch(IOException ex){
			System.out.print("There was an error reading the file");
		}
		
		return match;
		
	}
	
	/** method that handles firing the buttons when enter is pressed*/
	static void fireOnEnter(Button b){
		b.setOnKeyPressed(e -> {
			if(e.getCode().equals(KeyCode.ENTER) && b.isFocused())
				b.fire();
		});
	}
	
	/** Method that sets up the styles appearance of the button*/
	static Button setButton(String s){	
		Button b = new Button(s);
		b.setFont(Font.font("Abyssinica SIL", 20));
		b.setStyle("-fx-background-color: #616161; -fx-border-color: #616161; -fx-text-fill: #F1F1F1;"
				+ "-fx-border-radius: 15,15,15,15;");
		b.setMinWidth(150);
		b.setMinHeight(50);
		b.setFocusTraversable(true);	
		//set drop shadow
		 DropShadow dropShadow = new DropShadow();
			 dropShadow.setRadius(4.0);
			 dropShadow.setOffsetX(2.0);
			 dropShadow.setOffsetY(2.0);
			 dropShadow.setColor(Color.color(0.026, 0.108, 0.120)); 
			 b.setEffect(dropShadow);
		return b;
	}
	
	//empty main method
	public static void main(String[] args) {
		launch(args);
	}
}
