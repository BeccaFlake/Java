/*
Rebecca Flake
3-21-2018 Through 4-30-2018 
Java
Version 8
Includes: 
   Java-
	File, FileWriter, and IOException classes
	Scanner class
   JavaFx-
	Platform class
	EventHandler class
	HPos, Insets, and Pos classes
	Stage class
	Duration Class
	Button, CheckBox, ContentDisplay, Label, and TextField classes
	Drop shadow class
	Image and ImageView classes
	BorderPane, GridPane, HBox, StackPane, and VBox classes
	Media and MediaPlayer classes
	Color class
	Rectangle class
	Font and Text classes
   Files
    yGameData.txt
    yHighScore.txt
    Di1.jpg, Die2.jpg, Die3.jpg, Die4.jpg, Die5.jpg, Die6.jpg
    roll.mp3
COP2552.001
Final Project
This class allows the user to play a game of Yahtzee with a graphical user interface. The user can also view instructions on how to play, View the top ten scores 
of all time, and view the game data from the 10 most recently played games. They can also return to the game selection menu. Game data for each user is stored as a single record in the 
game data file. The high score information is kept separate, with only the top 10 scores of all time kept.
 */
package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

/**Yahtzee GUI Class*/

class YahtzeeGUI {
	//create an array of  images for the rolls
	static Image[] imageArray = {new Image("/Die1.jpg"), new Image("/Die2.jpg"), new Image("/Die3.jpg"), 
			new Image("/Die4.jpg"), new Image("/Die5.jpg"), new Image("/Die6.jpg") };
	//create the media player for the roll sound
	static MediaPlayer rollPlayer = new MediaPlayer(new Media(new File("resources/roll.mp3").toURI().toString())); 
	//Create the static file reference variables
	static File yHighScoreFile;
	static File yGameDataFile;		
	static Scanner yHighScoreFileIn;
	static Scanner yGameDataFileIn;
	static FileWriter yHighScoreFileOut;
	static FileWriter yGameDataFileOut;
	//variable for the username
	static String name = " ";
	//Game Data object for the games
	static GameData games;
	
	static void startYahtzee(Stage primaryStage, String n){
		//set the name for the game 
		name = n;
		
		//create the file objects
		yHighScoreFile = new File("yHighScore.txt");	
		yGameDataFile = new File("yGameData.txt");		
			
	try {
		//create new files if none exist
		if (!yHighScoreFile.exists()){
			 yHighScoreFileOut = new FileWriter(yHighScoreFile);
		}
		if (!yGameDataFile.exists()){
			 yGameDataFileOut = new FileWriter(yGameDataFile);
		}


		//create the game data object
		games = new GameData(yGameDataFile);	
		games.readData(yGameDataFile);
		
		primaryStage.setTitle("Yahtzee");
		//set the volume of the media player
		//Set the title of the primary stage
		primaryStage.setTitle("Yahtzee");
		//set the starting sizes for the stage
		primaryStage.setWidth(1200);
		primaryStage.setHeight(700);
		//set the minimum sizes for the stage
		primaryStage.setMinWidth(1200);
		primaryStage.setMinHeight(700);
		//Get the menu, which is the first scene
		getMenu(primaryStage);	
		
	} 
	//catch exceptions
	catch(Exception e) {
		e.printStackTrace();
	}
	}
	
	
	
	/* ******************************************************************************************************************************************************** 
	 * Methods that create the 'top level' scenes for the game. These include the menu * 
	 * scene method and the methods that will be called from the menu directly.		  *
	 * **************************************************************************************************************************************************** */
	/** Method that will create the main menu for the game*/
	static void getMenu(Stage primaryStage){
		//create the UI elements
		Button newGameBt = setButton("New Game");			//Button object that will allow the user to start a new game of blackjack
			newGameBt.setMinWidth(200);
		Button howToPlayBt = setButton("How to Play");			//Button object that will allow the user to view game instructions
			howToPlayBt.setMinWidth(200);
		Button highScoresBt = setButton("High Scores");			//Button object that will allow the user to see the top ten scores
			highScoresBt.setMinWidth(200);
		Button gameHistoryBt = setButton("Game History");		//Button object that will allow the user to see game history
			gameHistoryBt.setMinWidth(200);
		Button returnBt = setButton("Return to Game"
								+ "\nSelection Menu");		//Button object that will allow the user to return to the game selection menu
			returnBt.setMinWidth(200);
		Button exitBt = setButton("Exit");						//Button object that will allow the user to close the program
			exitBt.setMinWidth(200);		
			
		//Text object for the scene title
		Text gameNameTxt = new Text("1-Player Yahtzee");
			//set up the text's appearance
			gameNameTxt.setStyle(" -fx-text-fill: #001429; -fx-font-size: 2em;");
			gameNameTxt.setFont(Font.font("Abyssinica SIL", 24));
			
		//Create the VBox and add it's nodes
		VBox menuColumn = new VBox(35);
			menuColumn.getChildren().add(gameNameTxt);
			menuColumn.getChildren().add(newGameBt);
			menuColumn.getChildren().add(howToPlayBt);
			menuColumn.getChildren().add(highScoresBt);
			menuColumn.getChildren().add(gameHistoryBt);
			menuColumn.getChildren().add(returnBt);
			menuColumn.getChildren().add(exitBt);
			menuColumn.setAlignment(Pos.CENTER);
			
		//Create a border pane
		BorderPane menuPane = new BorderPane();
			menuPane.setCenter(menuColumn);		
			menuPane.setStyle("-fx-background-color: #86AAC0;");
		//Create a scene and place the plane into it, set it as the primary stage's scene
		//the height and width are set to what ever the current size of the primary stage - this seems to then apply to all scenes until it is overridden
		Scene menuScene = new Scene(menuPane, primaryStage.getWidth(), primaryStage.getHeight());
		primaryStage.setScene(menuScene);
			
		//Display the Stage
		primaryStage.show();	
		
		//Listeners for the stage size so that the scene can be resized
		primaryStage.widthProperty().addListener(ov -> {menuPane.setPrefWidth(primaryStage.getWidth());});
		primaryStage.heightProperty().addListener(ov-> {menuPane.setPrefHeight(primaryStage.getHeight());});
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(newGameBt);
		fireOnEnter(howToPlayBt);	
		fireOnEnter(highScoresBt);	
		fireOnEnter(gameHistoryBt);	
		fireOnEnter(returnBt);	
		fireOnEnter(exitBt);	
		//Event handlers for the buttons
			//Start a new game
		newGameBt.setOnAction(e -> startGame(primaryStage, name));
			//Get instructions
		howToPlayBt.setOnAction(e -> howToPlayDisplay(primaryStage));
			//Display the high scores
		highScoresBt.setOnAction(e -> highScoreDisplay(primaryStage));
			//Display the 10 most recently played games
		gameHistoryBt.setOnAction(e -> gameHistoryDisplay(primaryStage));
			//reutrn to the main menu
		returnBt.setOnAction(e-> Main.mainMenu());
			//exit the program
		exitBt.setOnAction(e -> exit());
		//handler for the window's exit button
		primaryStage.setOnCloseRequest(windowEvent -> {
			//consume the event
			windowEvent.consume();
			//then call exit to close the program gracefully if the user is sure
			exit();
		});
	}

	/** Method that creates a scene that gives the user instructions on how to play the game*/
	static void howToPlayDisplay(Stage primaryStage){
	//Create the UI Elements
		//A text object with the scene's title
		Text txt = new Text("Game Instructions");																				
			//Set the style for the text
			txt.setStyle("-fx-text-align: center; -fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			txt.setFont(Font.font("Abyssinica SIL", 26));
		//A text object to hold the instructions for the game
		Text instructions = new Text( "The game consists of 10 rounds. In each round you will complete "
				+ "3 rolls and then choose values to hold\nafter the first and second rolls.\n\n"
				+ "The first roll always uses all 6 dice, then the number of new dice in following"
				+ " rolls depends on the number of values\nyou picked out to hold.\n\n"
				+ "You will simply pick out the pictured rolls that you would like to keep, then confirm "
				+ "with the program that you are\nhappy with your selection. " 
				+ "The goal is to keep sets of numbers that fulfill certain scoring rules. "
				+ "\n\n The rules are as follows: " 
			    + "\n 	3 of a kind - Sum of the dice + 5 \n	4 of a kind - Sum of the dice + 10 \n 	"
			    + "Full house (2 matching dice AND 3 matching dice) - 25 points"
			    + "\n 	Small straight (4 dice in consecutive sequence) - 30 points \n "
			    + "	Large straight (all dice in consecutive sequence) - 40 points"
			    + "\n 	Yahtzee (all dice match) - 50 points \n 	"
			    + "Chance (anything else) - Sum of the dice "
			    + "\n\nYour score will only be considered for top score status if you complete all ten rounds.");	
			instructions.setStyle("-fx-line-height: 4em; -fx-font-size: 1.2em; -fx-text-fill: #001429;");
			instructions.setFont(Font.font("Abyssinica SIL", 25));
		//create a scroll pane to hold the history container
		ScrollPane scroll = new ScrollPane(instructions);
			scroll.setMaxWidth(1000);
			scroll.setMaxHeight(430);
			scroll.setPadding(new Insets(5,5,5,80));
			scroll.setStyle("-fx-background: #86AAC0; -fx-background-color: #86AAC0; ");
			
		//A button object that will allow the user to go back to the menu	
		Button backBt = setButton("Back to Menu");
		
		//A vertical box pane to hold the UL elements
		VBox vBox= new VBox();
			vBox.setAlignment(Pos.CENTER);
			vBox.setSpacing(15);
			vBox.setPadding(new Insets(5,5,5,5));
			vBox.getChildren().add(txt);
			vBox.getChildren().add(scroll);
			vBox.getChildren().add(backBt);

		//Create a border pane
		BorderPane howToPane = new BorderPane();
			howToPane.setCenter(vBox);
			howToPane.setStyle("-fx-background-color: #86AAC0;");
		//Set the scene and the stage, display it
		primaryStage.setScene(new Scene(howToPane, 700, 500));
		primaryStage.show();
		
		//allow the user to fire the button when they press enter and the the button has the focus
		fireOnEnter(backBt);	
		//event handler for the button
		backBt.setOnAction(e -> getMenu(primaryStage));
	}

	/** Method that shows the high scores*/
	static void highScoreDisplay(Stage primaryStage){
		//get the file input
		final int maxScore = 10;
		//create the file scanner
		yHighScoreFileIn	= GameData.createFileScanner(yHighScoreFile, yHighScoreFileIn);
		//create the line counter
		int lineCount = 0;
		String[] scores= new String[YahtzeeGame.ROUNDS];
		//get input from the file as long as the scanner isn't at the end of the file and the line count does't exceed the max number of scores
			while(yHighScoreFileIn.hasNext() && lineCount < maxScore){
 				//print all lines in the topScore file
 				scores[lineCount] = yHighScoreFileIn.nextLine();
 				lineCount++;
 				}
			//close the input scanner
			yHighScoreFileIn.close();
		
		//Create the title text
		Text highScoreTitleTxt = new Text("High Scores");
			highScoreTitleTxt.setStyle("-fx-text-align: center; -fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			highScoreTitleTxt.setFont(Font.font("Abyssinica SIL", 20));
		//create the textFields
		TextField score1Field = setTextField(scores[maxScore - 10], false, 25);
			score1Field.setFocusTraversable(false);
		TextField score2Field = setTextField(scores[maxScore - 9], false, 25);
			score2Field.setFocusTraversable(false);
		TextField score3Field = setTextField(scores[maxScore - 8], false, 25);
			score3Field.setFocusTraversable(false);
		TextField score4Field = setTextField(scores[maxScore - 7], false, 25);
			score4Field.setFocusTraversable(false);
		TextField score5Field = setTextField(scores[maxScore - 6], false, 25);
			score5Field.setFocusTraversable(false);
		TextField score6Field = setTextField(scores[maxScore - 5], false, 25);
			score6Field.setFocusTraversable(false);
		TextField score7Field = setTextField(scores[maxScore- 4], false, 25);
			score7Field.setFocusTraversable(false);
		TextField score8Field = setTextField(scores[maxScore - 3], false, 25);
			score8Field.setFocusTraversable(false);
		TextField score9Field = setTextField(scores[maxScore- 2], false, 25);
			score9Field.setFocusTraversable(false);
		TextField score10Field = setTextField(scores[maxScore - 1], false, 25);
			score10Field.setFocusTraversable(false);

		
		//create the labels for the textFields
		Label score1Lbl = new Label("1: ", score1Field);
			score1Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score2Lbl = new Label("2: ", score2Field);
			score2Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score3Lbl = new Label("3: ", score3Field);
			score3Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score4Lbl = new Label("4: ", score4Field);
			score4Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score5Lbl = new Label("5: ", score5Field);
			score5Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score6Lbl = new Label("6: ", score6Field);
			score6Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score7Lbl = new Label("7: ", score7Field);
			score7Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score8Lbl = new Label("8: ", score8Field);
			score8Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score9Lbl = new Label("9: ", score9Field);
			score9Lbl.setContentDisplay(ContentDisplay.RIGHT);
		Label score10Lbl = new Label("10: ", score10Field);
			score10Lbl.setContentDisplay(ContentDisplay.RIGHT);
			
		//create the button
		Button backBt = setButton("Back to Menu");
		
		//allow the user to fire the button when they press enter and the the button has the focus
		fireOnEnter(backBt);	
		//event handler for the button
		backBt.setOnAction(e -> getMenu(primaryStage));
		
		//create a vbox
		VBox highScoreVbox = new VBox();
			highScoreVbox.setStyle("-fx-background-color: #86AAC0;");
			highScoreVbox.setAlignment(Pos.CENTER);
			highScoreVbox.setSpacing(15);
			highScoreVbox.setAlignment(Pos.CENTER);
			highScoreVbox.setPadding(new Insets(10,10,10,10) );
			//add the nodes
			highScoreVbox.getChildren().add(highScoreTitleTxt);
			highScoreVbox.getChildren().add(score1Lbl);
			highScoreVbox.getChildren().add(score2Lbl);
			highScoreVbox.getChildren().add(score3Lbl);
			highScoreVbox.getChildren().add(score4Lbl);
			highScoreVbox.getChildren().add(score5Lbl);
			highScoreVbox.getChildren().add(score6Lbl);
			highScoreVbox.getChildren().add(score7Lbl);
			highScoreVbox.getChildren().add(score8Lbl);
			highScoreVbox.getChildren().add(score9Lbl);
			highScoreVbox.getChildren().add(score10Lbl);
			highScoreVbox.getChildren().add(backBt);

		//place the vBox in the scene
		Scene scene = new Scene(highScoreVbox, 700, 550);		
		primaryStage.setScene(scene);
		//Display the Stage
		primaryStage.show();
	}
	
	/** Method that shows the game history*/
	static void gameHistoryDisplay(Stage primaryStage){
		//a string for the game data
		String gameData = "";
		
	//read in the file information
		//create the file scanner
		yGameDataFileIn	= GameData.createFileScanner(yGameDataFile, yGameDataFileIn);
		//if the file length is not zero and there are still lines to read
		if(!(yGameDataFile.length() == 0)){
			while(yGameDataFileIn.hasNext() ){
				//add the next line of data to the string
 				gameData += yGameDataFileIn.nextLine() + "\n";
 				}
		}
		else{
			gameData = "There is no game history to show.";
		}
		//close the input scanner
			yGameDataFileIn.close();
			
	//Create the UI Elements
		//A text object with the scene's title
		Text gameHistoryTxt = new Text("Game History");																				
			//Set the style for the text
			gameHistoryTxt.setStyle("-fx-text-align: center; -fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			gameHistoryTxt.setFont(Font.font("Abyssinica SIL", 24));
		//A text object to hold the instructions for the game
		Text gameDataTxt = new Text(gameData);	
			gameDataTxt.setStyle("-fx-line-height: 4em;  -fx-text-fill: #001429;");
			gameDataTxt.setFont(Font.font("Abyssinica SIL", 20));
			gameDataTxt.setTextAlignment(TextAlignment.CENTER);

		//create a scroll pane to hold the history container
		ScrollPane scroll = new ScrollPane(gameDataTxt);
			scroll.setMaxWidth(500);
			scroll.setMaxHeight(400);	
			scroll.setStyle("-fx-background: #86AAC0; -fx-background-color: #86AAC0;");
			scroll.setPadding(new Insets(0,0,0, 82));
			
		//A button object that will allow the user to go back to the menu	
		Button backBt = setButton("Back to Menu");
		
		//A vertical box pane to hold the UL elements
		VBox vBox= new VBox();
			vBox.setAlignment(Pos.CENTER);
			vBox.setSpacing(15);
			vBox.setPadding(new Insets(5,5,5,5));		
			vBox.getChildren().add(gameHistoryTxt);
			vBox.getChildren().add(scroll);
			vBox.getChildren().add(backBt);

		//Create a border pane
		BorderPane gameDataPane = new BorderPane();
			gameDataPane.setStyle("-fx-background-color: #86AAC0;");
			gameDataPane.setCenter(vBox);
		//Set the scene and the stage, display it
		primaryStage.setScene(new Scene(gameDataPane, 700, 500));
		primaryStage.show();
		
		//allow the user to fire the button when they press enter and the the button has the focus
		fireOnEnter(backBt);	
		//event handler for the button
		backBt.setOnAction(e -> getMenu(primaryStage));
	}
	

	
	/* ***************************************************************************************************************************************************** * 
	 * Methods that create the 'lower level' scenes for the game, as well as setting up * 
	 * the game instance itself. These include the round scene, round score scene, and *
	 * the final score scene. They all are called only if a new game was created.     *
	 * **************************************************************************************************************************************************** */

	/**method that starts the game*/
	static void startGame(Stage primaryStage, String name){
		//Create an instance of the game
		YahtzeeGame game = new YahtzeeGame(name);
		//open the game data file for output
		yGameDataFileOut = GameData.createFileWriter(yGameDataFile, yHighScoreFileOut, false);
		
		//append date
		String DateLine = game.getDate() + "\n";
		games.updateUserRecord(name, DateLine);
		
		//begin the first round
		YahtzeeGUI.beginRound(primaryStage, game);
		
		//a handler for the window's exit button. We want to make sure the program closes gracefully
		primaryStage.setOnCloseRequest(windowEvent -> {
			//consume the event
			windowEvent.consume();
			//then call exit to make sure the program is closed gracefully if the user decides that is what they want
			hardQuit(game, primaryStage);
		});
	}
	
	/** Method that creates the GUI for the rounds of the game*/
	static void beginRound(Stage primaryStage, YahtzeeGame game){
	//Set up the static UI elements		
		//Check Boxes
		CheckBox cb1 = createCheckBox();
		CheckBox cb2 = createCheckBox();
		CheckBox cb3 = createCheckBox();
		CheckBox cb4 = createCheckBox();
		CheckBox cb5 = createCheckBox();
		//hold button 			
		Button holdBt =  setButton("Done");
		
		//if it is the first roll
		if(game.getRollCounter() == 0){
			//no values will have been held, make sure that the hold counter is zero
			game.setHoldCounter(0);		

			//play the roll sound	
			rollPlayer.play();
			//rewind roll sound
			rollPlayer.seek(Duration.ZERO);
			
			//roll the first set of numbers
			game.rollArray = game.roll(game.getRollCounter(), game.getHoldCounter());		
			//increment the roll
			game.setRollCounter(game.getRollCounter() + 1);
			
			//call the method that handles the holding and re-rolling, as well as creating the new scene
			Scene roundScene = createRoundScene(primaryStage, game,  cb1, cb2,  cb3,  cb4,  cb5 ,  holdBt);		
			primaryStage.setScene(roundScene);
			primaryStage.show();		
		}
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(holdBt);	
		//event handler for the hold button
		holdBt.setOnAction( event -> {
			//it is the second or third roll
			if(game.getRollCounter() > 0 && game.getRollCounter() < 3) {		
				//call the method that handles the holding and re-rolling, as well as creating the new scene
				holdRollHandler(cb1, cb2, cb3, cb4, cb5, holdBt, game, primaryStage);
			}
			//all of the holds and rolls have been completed, call the scoring GUI method
			else {roundScoreScene(game, primaryStage);}
		});				
	}
	
	
	
	/** Method that creates the scene for the round*/
	static Scene createRoundScene(Stage primaryStage, YahtzeeGame game, CheckBox cb1,CheckBox cb2, CheckBox cb3, CheckBox cb4, CheckBox cb5 , Button holdBt){
		//text for the UI
		Text roundNumTxt = new Text("Round " + (game.getRoundCounter() + 1));		//text object for the current round 																										//text object for the round number text
			roundNumTxt.setStyle("-fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			roundNumTxt.setFont(Font.font("Abyssinica SIL", 20));
			roundNumTxt.setTextAlignment(TextAlignment.CENTER);
		Text rollSetTxt = new Text("Rolls from roll " + (game.getRollCounter()));		//text object for the current roll																													//text object for the roll number text
			rollSetTxt.setStyle(" -fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			rollSetTxt.setFont(Font.font("Abyssinica SIL", 18));
			rollSetTxt.setTextAlignment(TextAlignment.CENTER);
		//text object for the instructions
		Text instructionsTxt = new Text("Click on the boxes below the rolls you would like to hold.\nClick the Done button when you are finished, "		
											+ "no matter how many you choose to hold.\nOnce you complete the third roll the round will be scored");
			instructionsTxt.setStyle(" -fx-text-fil: #001429; -fx-padding-to: 1.5em;");
			instructionsTxt.setFont(Font.font("Abyssinica SIL", 14));
			instructionsTxt.setTextAlignment(TextAlignment.CENTER);
			
		//if it is the last set of rolls, change the text
		if(game.getRollCounter() == 3){
			holdBt.setText("Score \nRound");
			instructionsTxt.setText("Here is your final set of rolls, click on the Score Round button to get your score for this round.");
		}
		
		//rectangles that will go underneath the roll images
		Rectangle sq1 = setRectangle();
		Rectangle sq2 = setRectangle();
		Rectangle sq3 = setRectangle();
		Rectangle sq4 = setRectangle();
		Rectangle sq5 = setRectangle();
		//Button
		Button quitBt =  setButton("Quit to Menu");
		//uncheck all of the check boxes
		cb1.setSelected(false);
		cb2.setSelected(false);
		cb3.setSelected(false);
		cb4.setSelected(false);
		cb5.setSelected(false);
		 
		//place the images in  image views
			/* the image is retrieved from an array of image objects. The index of the image object is the value 
			 * held in matching column in the most recently completed roll's row, minus 1*/
		ImageView imgV1 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][0]-1)]);
			imgV1.setFitHeight(100);
			imgV1.setFitWidth(100);
		ImageView imgV2 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][1]-1)]);
			imgV2.setFitHeight(100);
			imgV2.setFitWidth(100);
		ImageView imgV3 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][2]-1)]);
			imgV3.setFitHeight(100);
			imgV3.setFitWidth(100);
		ImageView imgV4 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][3]-1)]);
			imgV4.setFitHeight(100);
			imgV4.setFitWidth(100);
		ImageView imgV5 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][4]-1)]);
			imgV5.setFitHeight(100);
			imgV5.setFitWidth(100);
		
		//Place the Ui elements in their panes
			GridPane roundGridPane = new GridPane();
				roundGridPane.setStyle("-fx-background-color: #86AAC0;");
				roundGridPane.setAlignment(Pos.CENTER);
			//round number text and roll number text go in a vertical box that goes in the top middle of a grid pane
			VBox roundVbox1 = new VBox();
				roundVbox1.setPadding(new Insets(15, 10, 15 , 10));
				roundVbox1.setSpacing(20);
				roundVbox1.setAlignment(Pos.CENTER);
				roundVbox1.getChildren().add(roundNumTxt);
				roundVbox1.getChildren().add(instructionsTxt);
				roundVbox1.getChildren().add(rollSetTxt);		
				roundGridPane.add(roundVbox1, 0, 0);
			
			//each stack pane has a rectangle and a die image in it
			StackPane sp1 = createImageStack(sq1, imgV1);
			StackPane sp2 = createImageStack(sq2, imgV2);
			StackPane sp3 = createImageStack(sq3, imgV3);
			StackPane sp4 = createImageStack(sq4, imgV4);
			StackPane sp5 = createImageStack(sq5, imgV5);
			//they go in an hBox
			GridPane rollHoldGrid= new GridPane();
				rollHoldGrid.setAlignment(Pos.CENTER);
				rollHoldGrid.setPadding(new Insets(15, 10, 15, 10));
				rollHoldGrid.setHgap(20);
				rollHoldGrid.setVgap(20);
				//add the stack panes
				rollHoldGrid.add(sp1, 0, 0);
				GridPane.setHalignment(sp1, HPos.CENTER);
				rollHoldGrid.add(sp2, 1, 0);
				GridPane.setHalignment(sp2, HPos.CENTER);
				rollHoldGrid.add(sp3, 2, 0);
				GridPane.setHalignment(sp3, HPos.CENTER);
				rollHoldGrid.add(sp4, 3, 0);
				GridPane.setHalignment(sp4, HPos.CENTER);
				rollHoldGrid.add(sp5, 4, 0);
				GridPane.setHalignment(sp5, HPos.CENTER);
				
			//add the check boxes if it is not the final roll
			if(game.getRollCounter() < 3){
				//show the check boxes it if is not after the final roll
				rollHoldGrid.add(cb1, 0, 1);
				GridPane.setHalignment(cb1, HPos.CENTER);
				rollHoldGrid.add(cb2, 1, 1);
				GridPane.setHalignment(cb2, HPos.CENTER);
				rollHoldGrid.add(cb3, 2, 1);
				GridPane.setHalignment(cb3, HPos.CENTER);
				rollHoldGrid.add(cb4, 3, 1);
				GridPane.setHalignment(cb4, HPos.CENTER);
				rollHoldGrid.add(cb5, 4, 1);
				GridPane.setHalignment(cb5, HPos.CENTER);
				rollHoldGrid.add(holdBt, 2, 2);		
			}
			//don't show the check boxes if it is after the last roll
			else{
				rollHoldGrid.add(holdBt, 2, 1);		
			}
				//add the hold button
				GridPane.setHalignment(holdBt, HPos.CENTER);
				roundGridPane.add(rollHoldGrid, 0, 2);
			
			//the quit button goes in the center bottom of the grid pane
			VBox roundVbox2 = new VBox();
				roundVbox2.setPadding(new Insets(15, 10, 15 , 10));
				roundVbox2.setSpacing(20);
				roundVbox2.setAlignment(Pos.CENTER);
				roundVbox2.getChildren().add(quitBt);		
				roundGridPane.add(roundVbox2, 0, 4);
		//Place the main grid pane into the scene and then display the scene in the primary stage
		Scene roundScene = new Scene(roundGridPane, 700, 500);
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(quitBt);	
		//event handler for the quit button 
		quitBt.setOnAction(e -> quit(game, primaryStage));
		//return the scene
		return roundScene;
	}
	
	/** Method that sets up the round scoring scene*/
	static void roundScoreScene(YahtzeeGame game, Stage primaryStage){
	//Set up the UI Elements
		//text for the UI
		Text roundNumTxt = new Text("Round " + (game.getRoundCounter() +1) + " Score");			//text object that holds the text for the round number
			roundNumTxt.setStyle("-fx-text-align: center; -fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			roundNumTxt.setFont(Font.font("Abyssinica SIL", 20));
		Text rollSetTxt = new Text("Final Roll Set");												//text object that holds the text for the roll set
			rollSetTxt.setStyle("-fx-text-align: center; -fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			rollSetTxt.setFont(Font.font("Abyssinica SIL", 18));

		//rectangles that will go underneath the roll images
		Rectangle sq1 = setRectangle();
		Rectangle sq2 = setRectangle();
		Rectangle sq3 = setRectangle();
		Rectangle sq4 = setRectangle();
		Rectangle sq5 = setRectangle();
		//Create the text fields, which are not editable
		TextField roundScoreField = setTextField(false);
		TextField scoreRuleField = setTextField(false);
		TextField totalScoreField = setTextField(false);
		//Create the labels with their respective textFields, and set the display alignment to the right
		Label roundScoreLbl = new Label("The score for this round was: ", roundScoreField );
			roundScoreLbl.setContentDisplay(ContentDisplay.RIGHT);
		Label scoreRuleLbl = new Label("Using the scoring rule: ", scoreRuleField );
			scoreRuleLbl.setContentDisplay(ContentDisplay.RIGHT);
		Label totalScoreLbl = new Label("Your total score is now: ", totalScoreField );
			totalScoreLbl.setContentDisplay(ContentDisplay.RIGHT);
		//Buttons
		String roundBtTxt = "";
			//It is after the last round's completion
			if(game.getRoundCounter() == 9){roundBtTxt = "Calculate Final Score";}
			//it is before the last round's completion
			else{roundBtTxt = "Start Next Round";}
			
		Button nextRoundBt = setButton(roundBtTxt);
		Button quitBt =  setButton("Quit to Menu");
		
		//score the round
		game.scoreRound(games);	
		
		//place the images in image views
			/* the image is retrieved from an array of image objects. The index of the image object is the value 
			 * held in matching column in the most recently completed roll's row, minus 1*/
		ImageView imgV1 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][0] )-1]);
			imgV1.setFitHeight(100);
			imgV1.setFitWidth(100);
		ImageView imgV2 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][1]) -1]);
			imgV2.setFitHeight(100);
			imgV2.setFitWidth(100);
		ImageView imgV3 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][2]) -1]);
			imgV3.setFitHeight(100);
			imgV3.setFitWidth(100);
		ImageView imgV4 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][3]) -1]);
			imgV4.setFitHeight(100);
			imgV4.setFitWidth(100);
		ImageView imgV5 = new ImageView(imageArray[(game.rollArray[game.getRollCounter()-1][4] )-1]);
			imgV5.setFitHeight(100);
			imgV5.setFitWidth(100);
		
		//set the field text
			roundScoreField.setText(game.roundScoreArray[game.getRoundCounter()][2]);
			scoreRuleField.setText(game.roundScoreArray[game.getRoundCounter()][1]);
			totalScoreField.setText(Integer.toString(game.getScoreCounter()));
		//Place the Ui elements in their panes	
			//each stack pane has a rectangle and a die image in it
			StackPane sp1 = createImageStack(sq1, imgV1);
			StackPane sp2 = createImageStack(sq2, imgV2);
			StackPane sp3 = createImageStack(sq3, imgV3);
			StackPane sp4 = createImageStack(sq4, imgV4);
			StackPane sp5 = createImageStack(sq5, imgV5);
			//they go in an hBox
			GridPane rollGrid= new GridPane();
				rollGrid.setAlignment(Pos.CENTER);
				rollGrid.setPadding(new Insets(15, 10, 15 , 10));
				rollGrid.setHgap(20);
				rollGrid.setVgap(20);
			//add the stack panes
				rollGrid.add(sp1, 0, 0);
				rollGrid.add(sp2, 1, 0);
				rollGrid.add(sp3, 2, 0);
				rollGrid.add(sp4, 3, 0);
				rollGrid.add(sp5, 4, 0);
			
			//Create a vBox for the text fields and their labels
			VBox fieldVbox = new VBox();
				fieldVbox.setPadding(new Insets(15, 10, 15 , 10));
				fieldVbox.setSpacing(20);
				fieldVbox.setAlignment(Pos.CENTER);
				fieldVbox.getChildren().add(roundScoreLbl);
				fieldVbox.getChildren().add(scoreRuleLbl);
				fieldVbox.getChildren().add(totalScoreLbl);
			
			//place all of the major elements into the vBox
			VBox roundScoreVbox = new VBox();
				roundScoreVbox.setStyle("-fx-background-color: #86AAC0;");
				roundScoreVbox.setPadding(new Insets(15, 10, 15 , 10));
				roundScoreVbox.setSpacing(20);
				roundScoreVbox.setAlignment(Pos.CENTER);
				roundScoreVbox.getChildren().add(roundNumTxt);
				roundScoreVbox.getChildren().add(rollSetTxt);		
				roundScoreVbox.getChildren().add(rollGrid);
				roundScoreVbox.getChildren().add(fieldVbox);
				roundScoreVbox.getChildren().add(nextRoundBt);
				roundScoreVbox.getChildren().add(quitBt);		

		//Place the main grid pane into the scene and then display the scene in the primary stage		
		Scene roundScoreScene = new Scene(roundScoreVbox, 700, 520);
		//increment the round counter
		game.setRoundCounter(game.getRoundCounter() + 1);
		
		//show the scene
		primaryStage.setScene(roundScoreScene);
		primaryStage.show();
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(nextRoundBt);
		fireOnEnter(quitBt);	
		//event handler for the start next round button
		nextRoundBt.setOnAction( e ->{
				//less than 10 rounds have been played 
				if(game.getRoundCounter() < 10){
					//clear the array
					game.clearArray(game.rollArray);
					//set the roll counter to 0
					game.setRollCounter(0);
					//set the hold counter to 0
					game.setHoldCounter(0);
					//call beginRound
					beginRound(primaryStage, game);
				}
				//10 rounds have been played
				else{
					//call the final score method and end the game
					finalScoreScene(game, primaryStage);
				}
			});	
		//event handler for the quit button 
		quitBt.setOnAction(e -> quit(game, primaryStage));
	}
	
	/** Method that sets up the final scoring gui and calls methods that handle the final score comparison and file writing */
	static void finalScoreScene(YahtzeeGame game, Stage primaryStage){
		//Set up the up UI elements
			//set up the text objects
		Text finalScoreTitleTxt = new Text("Final Score");													//text object for the scene's title
			finalScoreTitleTxt.setStyle("-fx-text-align: center; -fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			finalScoreTitleTxt.setFont(Font.font("Abyssinica SIL", 20));
		Text finalScoreMessageTxt = new Text();															//text object for the text detailing the final score information
			finalScoreMessageTxt.setStyle("-fx-text-align: center; -fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			finalScoreMessageTxt.setFont(Font.font("Abyssinica SIL", 14));
			finalScoreMessageTxt.setTextAlignment(TextAlignment.CENTER);
		//call the high score comparison method
		//if it returns true
		if(game.compareScore(game.getScoreCounter(), game, yHighScoreFile)){
			finalScoreMessageTxt. setText("\nYour final score was " + game.getScoreCounter() + 
				"\nYour score was added to the top ten scores! \nGo check out the high scores to see how you did");
		}
		//the comparison returned false
		else{ 
			finalScoreMessageTxt.setText("Your final score was " + game.getScoreCounter());
		}
		
		Button yesBt =  setButton("Yes");
			yesBt.setMinWidth(50);
		Button noBt = setButton("No");
			noBt.setMinWidth(50);
		//put the buttons in a vertical box
		VBox buttonVbox = new VBox();
			buttonVbox.setPadding(new Insets(15, 10, 15 , 10));
			buttonVbox.setSpacing(20);
			buttonVbox.setAlignment(Pos.CENTER);
			buttonVbox.getChildren().add(yesBt);
			buttonVbox.getChildren().add(noBt);
		//create a label for the button vbox
		Label playAgainLbl = new Label("Would you like to play again?", buttonVbox );
			playAgainLbl.setStyle("-fx-text-align: center; -fx-text-fill: #001429; -fx-padding-top: 1.5em;");
			playAgainLbl.setFont(Font.font("Abyssinica SIL", 16));
			playAgainLbl.setContentDisplay(ContentDisplay.BOTTOM);
			
		//put all of the elements into a Vertical Box
		VBox finalScoreVBox = new VBox();
			finalScoreVBox.setStyle("-fx-background-color: #86AAC0;");
			finalScoreVBox.setPadding(new Insets(15, 10, 15 , 10));
			finalScoreVBox.setSpacing(20);
			finalScoreVBox.setAlignment(Pos.CENTER);
			finalScoreVBox.getChildren().add(finalScoreTitleTxt);
			finalScoreVBox.getChildren().add(finalScoreMessageTxt);
			finalScoreVBox.getChildren().add(playAgainLbl);
		//place the vbox into the scene
		Scene finalScoreScene = new Scene(finalScoreVBox, 700,500);
		primaryStage.setScene(finalScoreScene);
		primaryStage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(yesBt);	
		fireOnEnter(noBt);
		//event handler for the yes button
		yesBt.setOnAction(e -> 	{
				//append the final score to the record
				games.updateUserRecord(name, Integer.toString(game.getScoreCounter())+"\n");
			try{
				//overwrite the data in the file
				games.overwriteGameData(yGameDataFileOut);
				yGameDataFileOut.close();
			}
			catch(IOException ex){
				System.out.print("There was a problem with the file output in the game data function");
			}
			//return to the menu
			startGame(primaryStage, name);
		});
		//event handler for the no button 
		noBt.setOnAction(e -> quit(game, primaryStage));
	}
	
	 /* **************************************************************************************************************************** *
	 * Methods that deal with tasks related to specific events in the game *
	 * **************************************************************************************************************************** */
	
	/** Method that exits the application completely*/
	static void exit(){
	//create teh UI elements
		Text txt = new Text("Are you sure?");			//text object for the question
			txt.setStyle("-fx-text-align: center;");
			txt.setFont(Font.font("Abyssinica SIL", 16));
		Button yesBt =  setButton("Yes");
			yesBt.setMinWidth(50);
		Button noBt = setButton("No");
			noBt.setMinWidth(50);
		
		//hbox for the buttons
		HBox hBox= new HBox(20);
			hBox.setAlignment(Pos.CENTER);	
			hBox.getChildren().add(yesBt);
			hBox.getChildren().add(noBt);
		//vbox for the text and the buttons
		VBox vBox= new VBox(35);
			vBox.setAlignment(Pos.CENTER);		
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);

		//Create a border pane
		BorderPane exitPane = new BorderPane();
			exitPane.setStyle("-fx-background-color: #86AAC0;");
			exitPane.setCenter(vBox);
		//create the new scene
		Scene scene = new Scene(exitPane, 200, 150);		
		Stage stage = new Stage();
		stage.setScene(scene);
		//Display the Stage
		stage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(yesBt);	
		fireOnEnter(noBt);
		//Event handlers
		yesBt.setOnAction(e -> {
			//make sure the files are closed
			try{
				//file 1
				yGameDataFileIn.close();
				//file 2
				yHighScoreFileIn.close();
				//file 3
				yHighScoreFileOut.close();
				//file 4
				yGameDataFileOut.close();
			}
			catch(Exception ex){
				System.out.print("no files were open");
			}
			//close the application
			Platform.exit();
		});
		//if the answer is no, close the new stage
		noBt.setOnAction(e -> stage.close());
	}
	
	
	/** Method that returns the user to the main menu. it writes the the total score at the time to the file */
	static void quit(YahtzeeGame game, Stage primaryStage){
	//create the UI elements
		Text txt = new Text("Are you sure?");					//text object for the question
			txt.setStyle("-fx-text-align: center;");
			txt.setFont(Font.font("Abyssinica SIL", 16));
		Button yesBt =  setButton("Yes");
			yesBt.setMinWidth(50);
		Button noBt = setButton("No");
			noBt.setMinWidth(50);
		
		//hbox for the buttons
		HBox hBox= new HBox(20);
			hBox.getChildren().add(yesBt);
			hBox.getChildren().add(noBt);
			hBox.setAlignment(Pos.CENTER);
		//vbox for the text and buttons
		VBox vBox= new VBox(35);
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);
			vBox.setAlignment(Pos.CENTER);
		
		//Create a border pane
		BorderPane exitPane = new BorderPane();
			exitPane.setStyle("-fx-background-color: #86AAC0;");
			exitPane.setCenter(vBox);
		//create the new scene
		Scene scene = new Scene(exitPane, 200, 150);		
		Stage stage = new Stage();
		stage.setScene(scene);
		//Display the Stage
		stage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(yesBt);	
		fireOnEnter(noBt);
		//Event handlers
		yesBt.setOnAction(e -> {
			//append the final score to the record
			games.updateUserRecord(name, Integer.toString(game.getScoreCounter())+"\n" + GameData.gameDivider);
		try{
			//overwrite the data in the file
			games.overwriteGameData(yGameDataFileOut);
			yGameDataFileOut.close();
			}
			catch(IOException ex){
				System.out.print("The file was not open");
			}
			//close this stage
			stage.close();		
			//return to the menu
			getMenu(primaryStage);
			});
		//the answer was no, close the new stage
		noBt.setOnAction(e -> stage.close());
	}	
	

	/** Method exits the game completely while it is being played. It writes the current 
	 * high score to the file and makes sure that the files are closed*/
	static void hardQuit(YahtzeeGame game, Stage primaryStage){
	//create the UI elements
		Text txt = new Text("Are you sure?"						//text object for the question
				+ "\nYou will quit\nthe entire game.");
			txt.setStyle("-fx-text-align: center;");
			txt.setFont(Font.font("Abyssinica SIL", 14));
		Button yesBt =  setButton("Yes");
			yesBt.setMinWidth(50);
		Button noBt = setButton("No");
			noBt.setMinWidth(50);
		
		//hbox for the buttons
		HBox hBox= new HBox(20);
			hBox.getChildren().add(yesBt);
			hBox.getChildren().add(noBt);
			hBox.setAlignment(Pos.CENTER);
		//vbox for the text and buttons
		VBox vBox= new VBox(35);
			vBox.getChildren().add(txt);
			vBox.getChildren().add(hBox);
			vBox.setAlignment(Pos.CENTER);
		
		//Create a border pane
		BorderPane exitPane = new BorderPane();
			exitPane.setStyle("-fx-background-color: #86AAC0;");
			exitPane.setCenter(vBox);
		//create the new scene
		Scene scene = new Scene(exitPane, 200, 150);		
		Stage stage = new Stage();
		stage.setScene(scene);
		//Display the Stage
		stage.show();
		
		//allow the user to fire the buttons when they press enter and the the button has the focus
		fireOnEnter(yesBt);	
		fireOnEnter(noBt);
		//Event handlers
		yesBt.setOnAction(e -> {
			//append the final score to the record
			games.updateUserRecord(name, Integer.toString(game.getScoreCounter())+"\n");
		try{
			//overwrite the data in the file
			games.overwriteGameData(yGameDataFileOut);
			yGameDataFileOut.close();
			}
			catch(IOException ex){
				System.out.print("The file was not open");
			}
			//close this stage
			stage.close();
			//close the application
			Platform.exit();
			});
		//the answer was no, close the new stage
		noBt.setOnAction(e -> stage.close());
	}	
	
	/*event handler for the hold button that also rolls the new set of numbers*/
	static void holdRollHandler(CheckBox cb1, CheckBox cb2, CheckBox cb3, CheckBox cb4, CheckBox cb5, Button holdBt, YahtzeeGame game, Stage primaryStage ){
		//create a temporary array
		int tempArray[] = new int[YahtzeeGame.COLS];
		//reset holdcounter to 0
		game.setHoldCounter(0);
		
		//if the first checkbox is selected
		if(cb1.isSelected()){
			//place the value in the first element from the past roll into the row for roll that is about to happen's first element
			tempArray[game.getHoldCounter()] = game.rollArray[game.getRollCounter() -1][0];
			//increment the hold counter
			game.setHoldCounter(game.getHoldCounter() + 1);
		}
		//if the first checkbox is selected
		if(cb2.isSelected()){
			//place the value in the first element from the past roll into the row for roll that is about to happen's first element
			tempArray[game.getHoldCounter()] = game.rollArray[game.getRollCounter() -1][1];
			//increment the hold counter
			game.setHoldCounter(game.getHoldCounter() + 1);
		}
		//if the third checkbox is selected
		if(cb3.isSelected()){
			//place the value in the first element from the past roll into the row for roll that is about to happen's first element
			tempArray[game.getHoldCounter()] = game.rollArray[game.getRollCounter() -1][2];
			//increment the hold counter
			game.setHoldCounter(game.getHoldCounter() + 1);
		}
		//if the fourth checkbox is selected
		if(cb4.isSelected()){
			//place the value in the first element from the past roll into the row for roll that is about to happen's first element
			tempArray[game.getHoldCounter()] = game.rollArray[game.getRollCounter() -1][3];
			//increment the hold counter
			game.setHoldCounter(game.getHoldCounter() + 1);
		}
		//if the fifth checkbox is selected
		if(cb5.isSelected()){
			//place the value in the first element from the past roll into the row for roll that is about to happen's first element
			tempArray[game.getHoldCounter()] = game.rollArray[game.getRollCounter() -1][4];
			//increment the hold counter
			game.setHoldCounter(game.getHoldCounter() + 1);
		}
		//if hold > 0 play the roll sound
		if(game.getHoldCounter() < 5){
			rollPlayer.play();
			rollPlayer.seek(Duration.ZERO);
		}
		//if hold is > 0 then copy the contents of the temp array to the primary array
		if(game.getHoldCounter() > 0){
			for(int i =0; i < game.getHoldCounter(); i++){
				game.rollArray[game.getRollCounter()][i] = tempArray[i];
			}
		}
		
		//then roll is called, passing the number of held values over to it
		game.rollArray = game.roll(game.getRollCounter(), game.getHoldCounter());
		//increment the roll counter
		game.setRollCounter(game.getRollCounter() + 1);
		
		//create the new round scene
		Scene roundScene = createRoundScene(primaryStage, game,  cb1, cb2,  cb3,  cb4,  cb5 ,  holdBt);		
		//show the scene
		primaryStage.setScene(roundScene);
		primaryStage.show();
	}
	
	/** method that handles firing the buttons when enter is pressed*/
	static void fireOnEnter(Button b){
		b.setOnKeyPressed(e -> {
			if(e.getCode().equals(KeyCode.ENTER) && b.isFocused())
				b.fire();
		});
	}

	
	/* ************************************************************************************************************ *
	 * Methods that set up the appearance of specific node types *
	 * ************************************************************************************************************ */
	
	/** Method that sets up the styles appearance of the button*/
	static Button setButton(String s){
		Button b = new Button(s);
		b.setFont(Font.font("Abyssinica SIL", 16));
		b.setStyle("-fx-background-color: #377894; -fx-border-color: #377894; -fx-text-fill: #001429;"
				+ "-fx-border-radius: 15,15,15,15;");
		b.setMinWidth(100);
		b.setMinHeight(25);
		b.setFocusTraversable(true);
		//set drop shadow
		 DropShadow dropShadow = new DropShadow();
			 dropShadow.setRadius(4.0);
			 dropShadow.setOffsetX(2.0);
			 dropShadow.setOffsetY(2.0);
			 dropShadow.setColor(Color.color(0.026, 0.108, 0.120)); 
			 b.setEffect(dropShadow);
		return b;
	}
	
	/** Method that sets up the appearance of the rectangles*/
	static Rectangle setRectangle(){
		Rectangle r = new Rectangle();
		r.setWidth(110);
		r.setHeight(110);
		r.setFill(new Color(.33, .79, .95, .90));
		r.setArcWidth(15);
		r.setArcHeight(25);
		return r;
	}
	
	/**method that sets up the image stacks*/
	static StackPane createImageStack(Rectangle r, ImageView imgV){
		StackPane sp = new StackPane();
		sp.getChildren().add(r);
		sp.getChildren().add(imgV);
		return sp;
	}
	
	/** Method that sets up the check boxes */
	static CheckBox createCheckBox(){
		CheckBox cb = new CheckBox();
		cb.setSelected(false);
		cb.setContentDisplay(ContentDisplay.CENTER);
		return cb;
	}
	
	static TextField setTextField(Boolean edit){
		TextField textF = new TextField();
		textF.setStyle("-fx-background-color: #E1ECFC; ");
		textF.setFont(Font.font("Abyssinica SIL"));
		textF.setEditable(edit);
		return textF;
	}
	
	static TextField setTextField(String s, Boolean edit, int cols){
		TextField textF = new TextField(s);
		textF.setStyle("-fx-background-color: #E1ECFC; ");
		textF.setFont(Font.font("Abyssinica SIL"));
		textF.setEditable(edit);
		textF.setPrefColumnCount(cols);
		return textF;
	}

}
	
