/*
Rebecca Flake
3-21-2018 Through 4-30-2018
Java
Version 8
Includes: 
   	Scanner, random, Calendar, GregorianCalendar, File, FileWriter, and IOException classes
   Files
    yGameData.txt
    yHighScore.txt
COP2552.001
Final Project
This class file contains the yahtzeeGame class, which contains the methods and constructors for the processes that control the
game itself. This program is a simplified version of the game Yahtzee, which involves rolling dice
and keeping particular rolls in order to try and get the highest possible score. Scoring is based on
matches and consecutive sequences of numbers. It also generates random numbers to serve as the 'rolls', which are analogous to a D6 
 */
package application;

//imports
import java.util.Scanner;
import java.util.Random;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


class YahtzeeGame {
	//define and initialize the global variables and arrays
		//constant variables 
		static final int ROWS = 3,												//variable that holds the number of rows for the two dimensional array
					     COLS = 5,												//variable that holds the number of rows for the two dimensional array
					  ROUNDS= 10,												//variable that holds the number of possible rounds
				   	    COLS2 = 3;												//variable to hold the number of rows for the roundScore array
		//arrays
			//2-dimensional
		int[][] rollArray; 																//the main array that holds the rolls
		String[][] roundScoreArray;														//the array that holds the scores from each round
			//1-dimensional
		int[] holdArray;																//the array that holds the held values until they are placed in the final array
		String[] ruleArray =															//array that holds the rules for the scores. 
			{"Chance", "A full house", "A small straight", "A large straight", 
					"3 of a kind", "4 of a kind", "Yahzee"};
		
		//non-constant global variables
		private int scoreCounter,														//variable that holds the total score for each game
				    roundCounter,													//variable that holds the number of completed rounds
				     rollCounter,														//variable the holds the number of completed rolls
				    holdCounter;														//variable that holds the number of held values

		private String name,														//variable that holds the user's entered name
			    		date;														//variable that holds the current date

		//File Variables. They are all static because they do not depend on the instance
		Scanner yHighScoreFileIn;
		Scanner yHighScoreFileIn2;
		Scanner yGameDataFileIn;
		Scanner yGameDataFileIn2;
		FileWriter yHighScoreFileOut;
		FileWriter yGameDataFileOut;
		
	/**no-arg constructor */
	public YahtzeeGame(){
		//initialize a counter for the score to 0
	    scoreCounter = 0;
		//initialize a counter for the rounds to 0
	    roundCounter = 0;		
	    //initialize a counter for the rolls
	    rollCounter = 0;		
		//initialize a counter for the holds to 0
	    holdCounter = 0;
	    
	    //create a 2d arrays
		rollArray = new int[ROWS][COLS];
		roundScoreArray = new String[ROUNDS][COLS2];
		//create 1d array
		holdArray = new int[COLS];
		
		//initialize name to a a filler string
		name = "???";			
		
		//get the current date
		Calendar calendar = new GregorianCalendar();					//a Gregorian calendar object which we will use to get the current date
		int day  = calendar.get(Calendar.DATE);						//variable that will hold the current day of the month
		int month = calendar.get(Calendar.MONTH) +1;					//variable that will hold the current month. because the parameter is 0 based, 1 is added to it
		int year = calendar.get(Calendar.YEAR);						//variable that will hold the current year in yyyy format
		date = (month + "/" + day + "/" + year);							//variable that will hold the date string in m[m]/d[d]/yyyy format	
	}
	
	/**constructor that uses the name given*/
	public YahtzeeGame(String s){
		//initialize a counter for the score to 0
	    scoreCounter = 0;
		//initialize a counter for the rounds to 0
	    roundCounter = 0;		
		//initialize a counter for the rolls to 0
	    rollCounter = 0;		
		//initialize a counter for the holds to 0
	    holdCounter = 0;		
	    
	    //create a 2d arrays
		rollArray = new int[ROWS][COLS];
		roundScoreArray = new String[ROUNDS][COLS2];
		//create 1d array
		holdArray = new int[COLS];
	
		//initialize name to the given string
		name = s;			
		
		//get the current date
		Calendar calendar = new GregorianCalendar();					//a Gregorian calendar object which we will use to get the current date
		int day  = calendar.get(Calendar.DATE);						//variable that will hold the current day of the month
		int month = calendar.get(Calendar.MONTH) +1;					//variable that will hold the current month. because the parameter is 0 based, 1 is added to it
		int year = calendar.get(Calendar.YEAR);						//variable that will hold the current year in yyyy format
		date = (month + "/" + day + "/" + year);							//variable that will hold the date string in m[m]/d[d]/yyyy format
	}
	
	/* **************************** *
	 * Getter Methods *
	 * *************************** */
	/*method that gets the hold counter */
	String getName(){
		return name;
	}
	/*method that gets the hold counter */
	String getDate(){
		return date;
	}
	/*method that gets the hold counter */
	int getHoldCounter(){
		return holdCounter;
	}
	/*method that gets the hold counter */
	int getRollCounter(){
		return rollCounter;
	}
	/*method that gets the hold counter */
	int getRoundCounter(){
		return roundCounter;
	}
	/*method that gets the hold counter */
	int getScoreCounter(){
		return scoreCounter;
	}
	
	/* **************************** *
	 * Setter Methods *
	 * *************************** */
	/*method that sets the hold counter */
	void setHoldCounter(int holds){
		holdCounter = holds;
	}
	/*method that sets the roll counter */
	void setRollCounter(int rolls){
		rollCounter = rolls;
	}
	/*method that sets the round counter */
	void setRoundCounter(int rounds){
		roundCounter = rounds;
	}
	 
	/* ******************************************************************************************************************************** *
	 * Methods that run the behind the scenes operations of the game itself *
	 * ******************************************************************************************************************************* */
	
	/**method that rolls the numbers for the two dimensional array. It uses the the rollCounter and holdValue*/
	int[][] roll(int rollCounter, int holdValue){		
		int X = 0;													//variable to hold the number of values the player to roll
		//create an instance of the random class	
		Random rand = new Random();					

	   //X will be between 0 and 5, and is determined by how many numbers the player decides to hold
		switch(holdValue){
			//if the held number is 5, X = 0
			case 5: { X=0; break;}
			//if the held number is 4, X = 1
			case 4: { X=1; break;}
			//if the held number is 3, X = 2
			case 3: { X=2; break;}
			//if the held number is 2, X = 3
			case 2: { X=3; break;}
			//if the held number is 1, X = 4
			case 1: { X=4; break;}
			//if the held number is 0, X = 5
			case 0: { X=5; break;}
			//default should be zero
			default: {X=0; break;}
		}
		//The column index needs to work from the end of the row. So col is initialized to the column length minus one to avoid an out of bounds error
		int col  = (COLS - 1);	
		//Generate a random number between 1 and 6, X number of times	
		for (int i = 0; i < X; i++){	
			//if the indexes are somehow out of bounds, end the loop
			if (col < 0 || rollCounter > 3){break;}
			//get the rolled number
			int num = (1 + rand.nextInt(6));	
			/*place the random numbers into the LAST slots of the array because of how the hold method works
			*the values are placed in the row that corresponds to the roll number*/	
			rollArray[rollCounter][col] = num;		
			//decrement the column counter
			col--;
		}		
		//return the array of rolled values
		return rollArray;
	}

	/**method that scores the hand from the set of rolls*/
	void scoreRound(GameData games){
		int score = 0;														//variable to hold the round's score, it will be returned later
		final int SCORES = 7;												//constant variable to hold the number of elements for the score array.
		int [] scoreArray = new int[SCORES];								//array to hold the scores until it is determined which is the best
    	String rule = ruleArray[0];											//variable to hold the rule that was used determine the score, it holds chance by default
	  
		/*Only the third row’s values are used to determine which scoring rule to use.*/
		//make sure the last row is sorted, the method sorts each row in the array individually
		sortTwoDimensionalArray(rollArray);				
		/*The following are all single if statements, because I want to make sure that each one of the possible scores is checked for
		* then the best score will be chosen from the scores array*/
		
		//iterate though the last row of the array and check for: 
			//Yahtzee (all of the numbers are the same) - 50 points
		if (findMatches(rollArray) == 4){
			scoreArray[SCORES -1] = 50;
		}		
			//4 of a kind = sum of the dice + 10  points
	   if (findMatches(rollArray) == 3){
			scoreArray[SCORES - 2] = 10 + sumArrayValues(rollArray);
		}	
		//3 of a kind - sum of the dice + 5  points
	   if (findMatches(rollArray) == 2){
	     	scoreArray[SCORES - 3] = 5 + sumArrayValues(rollArray);
	   }			
		//large straight (all in consecutive sequence) - 40 points	
	 	if (searchArraySequence(rollArray) == 4){
			scoreArray[SCORES - 4] += 40;
		}
		//small straight (4 dice in consecutive sequence) - 30 points
		if (searchArraySequence(rollArray) == 3){
				scoreArray[SCORES - 5] += 30;
		}
		//full house (2 match and  3 match) - 25 points
		if(findMultiMatches(rollArray)){
			scoreArray[SCORES - 6] += 25;
		}
		//chance (anything else)- sum of all of the dice 
		scoreArray[SCORES - 7] = sumArrayValues(rollArray);
		
		//get and set the final score
		//find the highest score's index
		int scoreIndex = findScore(scoreArray);
		//set the score to the value held at the index
		score = scoreArray[scoreIndex];
		//add the score to the total score
		scoreCounter += score;
		//set the rule string to the contents of the matching element in the ruleArray
		rule = ruleArray[scoreIndex];
		String rolls = " ";
		for(int i = 0; i < COLS; i++){
			rolls += rollArray[ROWS-1][i];			
		}
	//place the score and the rule into the roundScoreArray
		//cast the score to a string
		String scoreS = Integer.toString(score);
		roundScoreArray[roundCounter][0] = rolls;
		roundScoreArray[roundCounter][1] = rule;
		roundScoreArray[roundCounter][2] = scoreS;
		String roundLine = roundScoreArray[roundCounter][0] + " | " + roundScoreArray[roundCounter][1] + " | " + roundScoreArray[roundCounter][2] + " points\n";
		games.updateUserRecord(name, roundLine);
	}
	
/* these two scoring methods are private, they will not be used outside of the YahtzeeGame class*/
	
	/** Method that looks for ONE set of matches in the array row. It returns how many matching numbers it found*/
	private int findMatches(int rollArray[][]) {
		int match = 0,								//variable that will hold the number of matches to return 
			 match1 = 0,							//variable to hold the number of found matches from the first search
			 match2 = 0,							//variable to hold the number of found matches from the second search
			 match3 = 0;							//variable to hold the number of found matches from the third search
		//Look for matches starting with the first element
		match1 = searchArrayMatch(rollArray, 0);	
		//Look for matches starting with the second element
		match2 = searchArrayMatch(rollArray, 1);		
		//Look for matches starting with the third element
		match3 = searchArrayMatch(rollArray, 2);
		
	//determine which match to return
		//the first search returned the highest number of matches
		if( match1 > match2 && match1 > match3){
			match = match1;
		}
		//the second search returned the highest number of matches
		else if(match2 > match1 && match2 > match3) {
			match = match2;
		}
		//the third search returned the highest number of matches
		else{
			match = match3;
		}
		return match;
	}
	
	/** method that looks for MULTIPLE sets of matches - it calls the seachArrayMatch method. 
	 * It returns a boolean describing if the conditions for a full house were met*/
	private boolean findMultiMatches(int[][] rollArray){
		/* With 5 elements there are only 2 possible ways there can be 2 of a kind and 3 of a kind when the array is sorted.
		 * The 3 of the kind has to be the first 3 elements in the array or the last 3 elements. So we only need to do 2 sets of checks*/
		boolean flag = false;									//variable to hold the result of the searches it will be returned, it defaults to false
		//there is 2 of a kind and three of a kind
		if ((searchArrayMatch(rollArray, 0) == 2 && searchArrayMatch(rollArray, 3) == 1) ||
		(searchArrayMatch(rollArray, 2) == 2 && searchArrayMatch(rollArray, 0) == 1)){
			flag = true;
		}
		//there is not 2 of a kind and 3 of a kind
		else{
			flag = false;
		}
		return flag;
	}

	/**method that checks if the game score is higher than the lowest score in the high score file then replaces it if needed */
	boolean compareScore(int scoreCounter, YahtzeeGame game, File yHighScoreFile){
		boolean newScore = false;									//a variable to hold the boolean value
		final int ROWS = 10;
		final int COLS = 3;
		//create the array to hold the input from the file
		String[][] inputArray = new String[ROWS][COLS];

		//create the input scanner 
		Scanner inputFile = GameData.createFileScanner(yHighScoreFile, yHighScoreFileIn);
		//a for loop that reads the values from the file into the array
		int scoresInFile = 0;
		if(yHighScoreFile.length() != 0){
			for(int i = 0; i < ROWS; i++){
				if(inputFile.hasNextLine()){
						//place the score in the array
						String fileLine  = inputFile.nextLine();
						//break the line up into tokens
						String[] tokens = fileLine.split("\\s");
						//put the tokens into the array elements
						inputArray[i][0] = tokens[0];
						//place the name in the array
						inputArray[i][1] = tokens[1];
						//place the date in the array
						inputArray[i][2] = tokens[2];
						//increment the lines in file counter
						scoresInFile++;
				}
			}
			//cast the score in the last row of the array (the lowest score) to an integer so it can be compared to the game score
			System.out.println(inputArray[scoresInFile-1][0]);
			//if there are not yet 10 scores in the file
			if(scoresInFile < ROWS){
				//add the new score to the inputArray
				inputArray[scoresInFile][0] = Integer.toString(scoreCounter);
				//add the name
				inputArray[scoresInFile][1] = game.name;
				//add the date
				inputArray[scoresInFile][2] = game.date;
				//sort the array
				inputArray = sortHighScoreFileArray(inputArray, (scoresInFile+1), COLS);
				//create the output file
				yHighScoreFileOut = GameData.createFileWriter(yHighScoreFile, yHighScoreFileOut, false);
				//re-write the file
				for(int i = 0; i < (scoresInFile+1); i++){
					String outputString  = inputArray[i][0] + " " +  inputArray[i][1] + " " +  inputArray[i][2] + "\n";
					GameData.writeToFile(yHighScoreFileOut, outputString);
				}
				newScore = true;
			}
			//there are 10 scores in the file
			else{
				int lowest = Integer.parseInt(inputArray[ROWS-1][0]);
				//if the game score is greater than or equal the lowest score from the file
				if(game.scoreCounter >= lowest){
					//replace the values in the last row of the array
					//replace the score
					inputArray[ROWS - 1][0] = Integer.toString(scoreCounter);
					//replace the name
					inputArray[ROWS - 1][1] = game.name;
					//replace the date
					inputArray[ROWS - 1][2] = game.date;
					//sort the array
					inputArray = sortHighScoreFileArray(inputArray, scoresInFile, COLS);
					//create the output file
					yHighScoreFileOut = GameData.createFileWriter(yHighScoreFile, yHighScoreFileOut, false);
					//re-write the file
					for(int i = 0; i < ROWS; i++){
						String outputString  = inputArray[i][0] + " " +  inputArray[i][1] + " " +  inputArray[i][2] + "\n";
						GameData.writeToFile(yHighScoreFileOut, outputString);
					}
					//set the boolean to true
					newScore = true;
				}
				//otherwise don't do anything
				else{;}	
			}
		}
		//there is no score in the file	
		else{
			//create the output file
			yHighScoreFileOut = GameData.createFileWriter(yHighScoreFile, yHighScoreFileOut, false);
			//write the score, name and date to the file.
			String highScoreOutputLine = game.scoreCounter + " " + game.name + " " + game.date + "\n";			//string variable that holds the line with the high score, name, and date
			GameData.writeToFile(yHighScoreFileOut, highScoreOutputLine);	
			newScore = true;
		}
			//close the file
		try{
			yHighScoreFileOut.close();
		}
		catch(IOException ex){
			System.out.println("There was an error closing the file in the compare high score method");
		}
		//return the boolean		
		return newScore;	
   }
 	
	
	/* ************************************************************************************** *
	 * Methods that directly interface with the arrays *
	 * ************************************************************************************* */

	/**method that clears the array*/
	void clearArray(int[][] rollArray){
		//reset the array values to 0
		for(int i = 0; i < ROWS; i++){
			for(int j = 0; j < COLS; j++){
				rollArray[i][j] = 0;
			}
		}
	}
	
/* these four scoring methods are private, they will not be used outside of the YahtzeeGame class */
	/**method that finds the highest score from the array of possible scores and returns its index */
	private int findScore(int[] scoreArray){
		int scoreIndex = 0,
				currentMax = scoreArray[0];
		for (int i = 1; i < scoreArray.length; i++){
			//if the value in the element is greater than the value in currentMax, 
			if (scoreArray[i] > currentMax){	
				//set currentMax to the value in the current element
				currentMax = scoreArray[i];
				//set the highest score's index to the current index
				scoreIndex = i;
			}
			//otherwise do nothing
			else{;}
		}
	return scoreIndex;	
   }
	
	/** Method that looks in the last row for matches, it is given the index to start the comparison at. It returns the number of matches it found*/
	private int searchArrayMatch(int rollArray[][], int startValue){
		int match = 0;
		/*i is the index after the given start value. It is increased each iteration
		 *  and the value at that index is compared to the value in the starting index*/
		for (int i = (startValue +1); i < COLS; i++){
			if(rollArray[ROWS-1][startValue] == rollArray[ROWS-1][i]){
				match++;
			}
		}
		return match;
	}
	
	/** Method that looks for numbers in consecutive sequence. It returns the number of values in a consecutive sequence.*/
	private int searchArraySequence(int rollArray[][]){
		int sequence = 0;
		//iterate through the array row
		for (int i= 0; i < COLS-1; i++){
			int value1 = rollArray[ROWS-1][i];					//the value in the current element
			int value2 = rollArray[ROWS-1][i+1];				//the value in the next element
			//if the value in the next index is equal to the value in the current index+1, add to the sequence counter
			if(value2 == (value1 + 1)){
				sequence++;
			}
			//the two elements are not in sequence
			else{;}
		}
		return sequence;
	}

	/**Method that sums the values in the last row of two dimensional array. It returns the calculated score*/
	private int sumArrayValues(int[][] rollArray){
		int score = 0;
		for (int i= 0; i < COLS; i++){
			//add the value at the current element to the score
			score += rollArray[ROWS-1][i] ;
		}
		return score;
	}
	
	/** Method that sorts the two dimensional array */
	void sortTwoDimensionalArray(int[][] rollArray){
		//iterate through the array, once for each row 
		for(int row =0; row < 3; row++){
			//iterate through the elements of the row
			for (int i= 0; i < rollArray[row].length; i++){
				int currentMin = rollArray[row][i];
				int currentMinIndex = i;
				//find the minimum and put it in the correct spot
				for (int j = i+1; j < rollArray[row].length; j++){
					if (currentMin > rollArray[row][j]){
						currentMin = rollArray[row][j];
						currentMinIndex = j;
					}	
				}
				//Swap if necessary and prepare for the next iteration
				if(currentMinIndex != i){
					rollArray[row][currentMinIndex] = rollArray[row][i];
					rollArray[row][i] = currentMin;
				}
			}
		}	
	}
	
	/** Method that sorts the scores from the high score file. It is private, as it is only used within this class */
	private String[][] sortHighScoreFileArray(String[][] fileArray, final int ROWS, final int COLS){
		String[] tempArray = new  String[COLS];
		//for each row in the array-1, working from the last row to the first
		for(int i = ROWS-1; i > 0; i--){
			//create the integer variables to be compared
			int score1= Integer.parseInt(fileArray[i][0]);						//integer variable to hold the score value from the current row
			int score2 = Integer.parseInt(fileArray[i-1][0]);						//integer variable to hold the score value from the 'next' row
			//if the score in the current row is greater than or equal to the score in the next row
			if(score1 >= score2){
				//place the values from the 'next' row in the temporary array
				tempArray[0] = fileArray[i-1][0];
				tempArray[1] = fileArray[i-1][1];
				tempArray[2] = fileArray[i-1][2];
				//place the values from the current row into the 'next' row
				fileArray[i-1][0]=fileArray[i][0];
				fileArray[i-1][1]=fileArray[i][1];
				fileArray[i-1][2]=fileArray[i][2];
				//place the values from the temp array into the current row. A swap has been made
				fileArray[i][0] = tempArray[0];
				fileArray[i][1] = tempArray[1];
				fileArray[i][2] = tempArray[2];
			}
			//otherwise do nothing
			else{;}
		}
		return fileArray;
	}
	
	//Empty main method
	static void main(String[] args) {
	}
}
